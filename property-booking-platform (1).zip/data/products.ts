import type { Product } from "@/types/product"

export const products: Product[] = [
  {
    id: "1",
    name: "Diamond Cabin",
    description:
      "A luxurious A-frame cabin nestled in the forest, featuring modern architecture with floor-to-ceiling windows and a private balcony.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/f11ce9b8-8e81-4388-a9ee-9a1b624baefd.jpg-px8MUsvjHAogrFlvezRQJHmLSpBMAP.jpeg",
    price: 0.0001,
    availableUnits: 1,
    location: "Pacific Northwest",
  },
  {
    id: "2",
    name: "Glashaus",
    description:
      "A stunning modern glass house surrounded by a wildflower garden, featuring minimalist design with perforated metal panels and contemporary interiors.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-05%20014232-YOZtrD5ogaxOPA4velshnwVJcNJVox.png",
    price: 0.0001,
    availableUnits: 1,
    location: "Hudson Valley, NY",
  },
]

