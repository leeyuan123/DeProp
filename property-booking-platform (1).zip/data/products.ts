import type { Product } from "@/types/product"

export const products: Product[] = [
  {
    id: "1",
    name: "Diamond Cabin",
    description:
      "A luxurious A-frame cabin model featuring modern architecture with floor-to-ceiling windows and a private balcony.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/f11ce9b8-8e81-4388-a9ee-9a1b624baefd.jpg-px8MUsvjHAogrFlvezRQJHmLSpBMAP.jpeg",
    price: 1,
    inventory: 10,
    stock: "In Stock",
  },
  {
    id: "2",
    name: "Glashaus",
    description:
      "A stunning modern glass house model surrounded by a miniature wildflower garden, featuring minimalist design with perforated metal panels.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-05%20014232-YOZtrD5ogaxOPA4velshnwVJcNJVox.png",
    price: 1,
    inventory: 5,
    stock: "Limited Stock",
  },
]

