import type { Property } from "@/types/property"

export const properties: Property[] = [
  {
    id: "1",
    name: "Diamond Cabin",
    description:
      "A luxurious A-frame cabin nestled in the forest, featuring modern architecture with floor-to-ceiling windows and a private balcony.",
    location: "Pacific Northwest",
    type: "Residential",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/f11ce9b8-8e81-4388-a9ee-9a1b624baefd.jpg-px8MUsvjHAogrFlvezRQJHmLSpBMAP.jpeg",
    pricePerNight: 0.0001,
    fundingGoal: 0.001,
    fundingCurrent: 0.0003,
    expectedRoi: 8.5,
    minInvestment: 0.0001,
  },
  {
    id: "2",
    name: "Glashaus",
    description:
      "A stunning modern glass house surrounded by a wildflower garden, featuring minimalist design with perforated metal panels and contemporary interiors.",
    location: "Hudson Valley, NY",
    type: "Residential",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-05%20014232-YOZtrD5ogaxOPA4velshnwVJcNJVox.png",
    pricePerNight: 0.0001,
    fundingGoal: 0.001,
    fundingCurrent: 0.0003,
    expectedRoi: 7.2,
    minInvestment: 0.0001,
  },
]

