export interface Property {
  id: string
  name: string
  description: string
  location: string
  type: string
  image?: string
  pricePerNight: number
  fundingGoal: number
  fundingCurrent: number
  expectedRoi: number
  minInvestment: number
}

