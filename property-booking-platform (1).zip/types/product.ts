export interface Product {
  id: string
  name: string
  description: string
  image?: string
  price: number
  inventory: number // Changed from availableUnits
  stock: string // Changed from location
}

