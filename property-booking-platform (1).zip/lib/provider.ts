import { ethers } from "ethers"
import { SCROLL_SEPOLIA_CONFIG } from "./contract-config"

// Update the createProvider function to completely disable ENS
export function createProvider(ethereum?: any) {
  // For direct RPC connections (no wallet)
  if (!ethereum) {
    // Create a provider with ENS completely disabled
    const provider = new ethers.JsonRpcProvider(SCROLL_SEPOLIA_CONFIG.rpcUrls[0], {
      chainId: 534351,
      name: "scroll-sepolia",
    })

    // Override ENS methods to prevent any ENS resolution attempts
    provider.resolveName = async (name: string) => {
      // If it looks like an address, return it; otherwise return null
      return ethers.isAddress(name) ? name : null
    }

    provider.lookupAddress = async (address: string) => {
      return null
    }

    return provider
  }

  // For wallet connections
  const provider = new ethers.BrowserProvider(ethereum, {
    chainId: 534351,
    name: "scroll-sepolia",
  })

  // Override ENS methods to prevent any ENS resolution attempts
  const originalResolveName = provider.resolveName.bind(provider)
  provider.resolveName = async (name: string) => {
    // If it looks like an address, return it; otherwise return null
    return ethers.isAddress(name) ? name : null
  }

  const originalLookupAddress = provider.lookupAddress.bind(provider)
  provider.lookupAddress = async (address: string) => {
    return null
  }

  return provider
}

// Get a signer from the provider
export async function getSigner(ethereum: any) {
  if (!ethereum) {
    throw new Error("Ethereum provider not available")
  }
  const provider = createProvider(ethereum)
  return await provider.getSigner()
}

