// This is a simulation of a smart contract for the MVP
// It stores data in localStorage to persist between sessions

export class VirtualContract {
  private contractAddress: string

  constructor() {
    // Use the environment variable or a default value
    this.contractAddress = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS || "0xVirtualContract"
  }

  // Get user balance
  async getBalance(address: string): Promise<number> {
    const key = `${this.contractAddress}_balance_${address}`
    const storedBalance = localStorage.getItem(key)

    if (storedBalance) {
      return Number.parseFloat(storedBalance)
    }

    // Default initial balance for new users
    const initialBalance = 1000
    localStorage.setItem(key, initialBalance.toString())
    return initialBalance
  }

  // Get user invested amount
  async getInvestedAmount(address: string): Promise<number> {
    const key = `${this.contractAddress}_invested_${address}`
    const storedAmount = localStorage.getItem(key)

    if (storedAmount) {
      return Number.parseFloat(storedAmount)
    }

    return 0
  }

  // Invest in property
  async invest(address: string, amount: number, propertyId: string): Promise<boolean> {
    if (!address || amount <= 0) {
      throw new Error("Invalid parameters")
    }

    // Get current balance
    const balance = await this.getBalance(address)

    if (balance < amount) {
      throw new Error("Insufficient balance")
    }

    // Update balance
    const newBalance = balance - amount
    localStorage.setItem(`${this.contractAddress}_balance_${address}`, newBalance.toString())

    // Update invested amount
    const currentInvested = await this.getInvestedAmount(address)
    const newInvested = currentInvested + amount
    localStorage.setItem(`${this.contractAddress}_invested_${address}`, newInvested.toString())

    // Store investment details
    const investments = this.getInvestments(address)
    investments.push({
      propertyId,
      amount,
      timestamp: Date.now(),
    })
    localStorage.setItem(`${this.contractAddress}_investments_${address}`, JSON.stringify(investments))

    // Simulate blockchain delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return true
  }

  // Book a property
  async bookProperty(
    address: string,
    propertyId: string,
    checkIn: string,
    checkOut: string,
    amount: number,
  ): Promise<boolean> {
    if (!address || !propertyId || !checkIn || !checkOut || amount <= 0) {
      throw new Error("Invalid parameters")
    }

    // Get current balance
    const balance = await this.getBalance(address)

    if (balance < amount) {
      throw new Error("Insufficient balance")
    }

    // Check if user has invested enough to book
    const investedAmount = await this.getInvestedAmount(address)
    const minimumInvestment = 100 // Minimum investment required to book

    if (investedAmount < minimumInvestment) {
      throw new Error(`You need to invest at least ${minimumInvestment} USDT to book a property`)
    }

    // Update balance
    const newBalance = balance - amount
    localStorage.setItem(`${this.contractAddress}_balance_${address}`, newBalance.toString())

    // Store booking details
    const bookings = this.getBookings(address)
    bookings.push({
      propertyId,
      checkIn,
      checkOut,
      amount,
      timestamp: Date.now(),
    })
    localStorage.setItem(`${this.contractAddress}_bookings_${address}`, JSON.stringify(bookings))

    // Simulate blockchain delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return true
  }

  // Get user investments
  getInvestments(address: string): Array<{ propertyId: string; amount: number; timestamp: number }> {
    const key = `${this.contractAddress}_investments_${address}`
    const storedInvestments = localStorage.getItem(key)

    if (storedInvestments) {
      return JSON.parse(storedInvestments)
    }

    return []
  }

  // Get user bookings
  getBookings(
    address: string,
  ): Array<{ propertyId: string; checkIn: string; checkOut: string; amount: number; timestamp: number }> {
    const key = `${this.contractAddress}_bookings_${address}`
    const storedBookings = localStorage.getItem(key)

    if (storedBookings) {
      return JSON.parse(storedBookings)
    }

    return []
  }

  // Add funds (for testing purposes)
  async addFunds(address: string, amount: number): Promise<boolean> {
    if (!address || amount <= 0) {
      throw new Error("Invalid parameters")
    }

    const balance = await this.getBalance(address)
    const newBalance = balance + amount
    localStorage.setItem(`${this.contractAddress}_balance_${address}`, newBalance.toString())

    // Simulate blockchain delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    return true
  }
}

