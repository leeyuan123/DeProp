"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { ethers } from "ethers"
import { useToast } from "@/components/ui/use-toast"
import { CONTRACT_ADDRESS, CONTRACT_ABI, SCROLL_SEPOLIA_CONFIG } from "@/lib/contract-config"
// Update the imports
import { createProvider, getSigner } from "@/lib/provider"

interface Web3ContextType {
  address: string | null
  isConnected: boolean
  isConnecting: boolean
  connectWallet: () => Promise<void>
  disconnectWallet: () => void
  ethBalance: string
  contract: any // Replace 'any' with your actual contract type
  isMockData: boolean
  isCorrectNetwork: boolean
  switchNetwork: () => Promise<void>
  CONTRACT_ADDRESS: string // Add this line
  getSigner: (ethereum: any) => Promise<ethers.Signer> // Add this line
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined)

const LOCAL_STORAGE_KEY = "wallet_address"
const SCROLL_SEPOLIA_CHAIN_ID = SCROLL_SEPOLIA_CONFIG.chainId // Chain ID for Scroll Sepolia testnet in hex

// Update the relevant parts of the Web3Context
export function Web3Provider({ children }: { children: ReactNode }) {
  const [address, setAddress] = useState<string | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [ethBalance, setEthBalance] = useState("0")
  const [contract, setContract] = useState<any>(null)
  const [isMockData, setIsMockData] = useState(false)
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(false)
  const { toast } = useToast()

  // Initialize from localStorage
  useEffect(() => {
    const savedAddress = localStorage.getItem(LOCAL_STORAGE_KEY)
    if (savedAddress) {
      setAddress(savedAddress)
      setIsConnected(true)
      refreshBalance(savedAddress)
    }
  }, [])

  const refreshBalance = async (walletAddress: string) => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const provider = createProvider(window.ethereum)
        const balance = await provider.getBalance(walletAddress)
        setEthBalance(ethers.formatEther(balance))
      } catch (error) {
        console.error("Failed to fetch balance:", error)
      }
    }
  }

  const checkNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const chainId = await window.ethereum.request({ method: "eth_chainId" })
        const isScrollSepolia = chainId === SCROLL_SEPOLIA_CHAIN_ID
        setIsCorrectNetwork(isScrollSepolia)
        return isScrollSepolia
      } catch (error) {
        console.error("Failed to check network:", error)
        return false
      }
    }
    return false
  }

  const switchNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: SCROLL_SEPOLIA_CHAIN_ID }],
        })
        return true
      } catch (error: any) {
        // This error code indicates that the chain has not been added to MetaMask
        if (error.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [SCROLL_SEPOLIA_CONFIG],
            })
            return true
          } catch (addError) {
            console.error("Failed to add Scroll Sepolia network:", addError)
            return false
          }
        }
        console.error("Failed to switch network:", error)
        return false
      }
    }
    return false
  }

  const initializeContract = async () => {
    if (typeof window.ethereum !== "undefined" && address) {
      try {
        const signer = await getSigner(window.ethereum)
        const contractInstance = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)
        setContract(contractInstance)
        setIsMockData(false)
        return contractInstance
      } catch (error) {
        console.error("Failed to initialize contract:", error)
        initializeMockContract()
        return null
      }
    } else {
      initializeMockContract()
      return null
    }
  }

  const initializeMockContract = () => {
    console.log("Initializing mock contract...")
    setIsMockData(true)

    const mockContract = {
      getOrderIds: async () => ["1", "2", "3"],
      getOrder: async (id: string) => ({
        projectName: `Mock Project ${id}`,
        amountInvested: BigInt("1000000000000000000"), // 1 ETH
        status: "Pending",
        sharedWalletBalance: BigInt("10000000000000000000"), // 10 ETH
        percentageOwnership: 10,
        estimatedAnnualReturn: BigInt("100000000000000000"), // 0.1 ETH
      }),
      confirmOrder: async (orderId: string) => {
        console.log(`Mock: Confirming order ${orderId}`)
        return true
      },
      adjustInvestment: async (orderId: string, newAmount: bigint) => {
        console.log(`Mock: Adjusting investment for order ${orderId} to ${newAmount}`)
        return true
      },
      cancelOrder: async (orderId: string) => {
        console.log(`Mock: Cancelling order ${orderId}`)
        return true
      },
      withdrawInvestment: async (orderId: string) => {
        console.log(`Mock: Withdrawing investment for order ${orderId}`)
        return true
      },
      placeOrder: async (projectId: number, seller: string, options: { value: bigint }) => {
        console.log(`Mock: Placing order for project ${projectId} with seller ${seller} and value ${options.value}`)
        return true
      },
      orders: async (orderId: number) => {
        return {
          orderId: orderId,
          projectId: 1,
          amount: BigInt("1000000000000000000"), // 1 ETH
          buyer: address || "0x0000000000000000000000000000000000000000",
          seller: "0x0000000000000000000000000000000000000001",
          status: 0, // Pending
        }
      },
      nextOrderId: async () => 4,
      projects: async (projectId: number) => {
        return {
          projectId: projectId,
          totalInvestment: BigInt("3000000000000000000"), // 3 ETH
          poolThreshold: BigInt("10000000000000000000"), // 10 ETH
          factoryAccount: "0x0000000000000000000000000000000000000002",
          fundsReleased: false,
          investorCount: 3,
        }
      },
    }

    setContract(mockContract)
    return mockContract
  }

  // Update the connectWallet function
  const connectWallet = async () => {
    if (isConnecting) return
    setIsConnecting(true)

    try {
      if (typeof window.ethereum === "undefined") {
        toast({
          title: "Error",
          description: "Please install MetaMask to use this app.",
          variant: "destructive",
        })
        return
      }

      // Request accounts using the ethereum object directly
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })
      const address = accounts[0]

      setAddress(address)
      setIsConnected(true)
      localStorage.setItem(LOCAL_STORAGE_KEY, address)

      await refreshBalance(address)

      // Check if we're on the correct network
      const networkCorrect = await checkNetwork()
      if (!networkCorrect) {
        toast({
          title: "Wrong Network",
          description: "Please switch to the Scroll Sepolia testnet to use this app.",
          variant: "destructive",
        })
      }

      // Initialize the contract
      await initializeContract()

      toast({
        title: "Success",
        description: "Wallet connected successfully",
      })
    } catch (error) {
      console.error("Failed to connect wallet:", error)
      toast({
        title: "Error",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnectWallet = () => {
    setAddress(null)
    setIsConnected(false)
    setEthBalance("0")
    localStorage.removeItem(LOCAL_STORAGE_KEY)
    toast({ title: "Success", description: "Wallet disconnected" })
  }

  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      window.ethereum.on("accountsChanged", (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet()
        } else {
          setAddress(accounts[0])
          localStorage.setItem(LOCAL_STORAGE_KEY, accounts[0])
          refreshBalance(accounts[0])
          initializeContract()
        }
      })

      window.ethereum.on("chainChanged", () => {
        checkNetwork()
        initializeContract()
      })
    }

    return () => {
      if (typeof window.ethereum !== "undefined") {
        window.ethereum.removeAllListeners()
      }
    }
  }, [])

  // Initialize contract when address changes
  useEffect(() => {
    if (address) {
      initializeContract()
      checkNetwork()
    }
  }, [address])

  const contextValue = {
    address,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet,
    ethBalance,
    contract,
    isMockData,
    isCorrectNetwork,
    switchNetwork,
    CONTRACT_ADDRESS, // Add this line
    getSigner, // Add this line
  }

  return <Web3Context.Provider value={contextValue}>{children}</Web3Context.Provider>
}

export function useWeb3() {
  const context = useContext(Web3Context)
  if (context === undefined) {
    throw new Error("useWeb3 must be used within a Web3Provider")
  }
  return context
}

