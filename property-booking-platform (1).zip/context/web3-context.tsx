"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { ethers } from "ethers"
import { useToast } from "@/components/ui/use-toast"

const contractABI = [
  {
    inputs: [
      { internalType: "address", name: "propertyId", type: "address" },
      { internalType: "uint256", name: "amount", type: "uint256" },
    ],
    name: "invest",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [
      { internalType: "address", name: "propertyId", type: "address" },
      { internalType: "uint256", name: "checkIn", type: "uint256" },
      { internalType: "uint256", name: "checkOut", type: "uint256" },
    ],
    name: "bookProperty",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "account", type: "address" }],
    name: "balanceOf",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
]

const SCROLL_SEPOLIA_CONFIG = {
  chainId: "0x8274f", // 534351 in decimal
  chainName: "Scroll Sepolia",
  nativeCurrency: {
    name: "Ethereum",
    symbol: "ETH",
    decimals: 18,
  },
  rpcUrls: ["https://sepolia-rpc.scroll.io/"],
  blockExplorerUrls: ["https://sepolia-explorer.scroll.io/"],
}

const FALLBACK_CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000"

interface Web3ContextType {
  address: string | null
  isConnected: boolean
  isConnecting: boolean
  connectWallet: () => Promise<void>
  disconnectWallet: () => void
  contract: ethers.Contract | null
  balance: number
  refreshBalance: () => Promise<void>
  chainId: string | null
  isCorrectNetwork: boolean
  switchNetwork: () => Promise<void>
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined)

export function Web3Provider({ children }: { children: ReactNode }) {
  const [address, setAddress] = useState<string | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [contract, setContract] = useState<ethers.Contract | null>(null)
  const [balance, setBalance] = useState(0)
  const [chainId, setChainId] = useState<string | null>(null)
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(false)
  const { toast } = useToast()

  const checkNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      const currentChainId = await window.ethereum.request({ method: "eth_chainId" })
      setChainId(currentChainId)
      setIsCorrectNetwork(currentChainId === SCROLL_SEPOLIA_CONFIG.chainId)
    }
  }

  useEffect(() => {
    checkNetwork()
    if (typeof window.ethereum !== "undefined") {
      window.ethereum.on("chainChanged", checkNetwork)
    }
    return () => {
      if (typeof window.ethereum !== "undefined") {
        window.ethereum.removeListener("chainChanged", checkNetwork)
      }
    }
  }, []) // Removed checkNetwork from dependencies

  const switchNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: SCROLL_SEPOLIA_CONFIG.chainId }],
        })
      } catch (switchError: any) {
        // This error code indicates that the chain has not been added to MetaMask
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [SCROLL_SEPOLIA_CONFIG],
            })
          } catch (addError) {
            toast({
              title: "Error",
              description: "Failed to add the Scroll Sepolia network to your wallet.",
              variant: "destructive",
            })
          }
        } else {
          toast({
            title: "Error",
            description: "Failed to switch to the Scroll Sepolia network.",
            variant: "destructive",
          })
        }
      }
    }
  }

  const connectWallet = async () => {
    if (isConnecting) return
    setIsConnecting(true)

    try {
      if (typeof window.ethereum === "undefined") {
        toast({
          title: "Error",
          description: "Please install MetaMask to use this app.",
          variant: "destructive",
        })
        return
      }

      await switchNetwork()
      await checkNetwork()

      if (!isCorrectNetwork) {
        toast({
          title: "Wrong Network",
          description: "Please switch to the Scroll Sepolia network in your wallet.",
          variant: "destructive",
        })
        return
      }

      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })
      const address = accounts[0]
      setAddress(address)
      setIsConnected(true)

      const provider = new ethers.BrowserProvider(window.ethereum)
      const signer = await provider.getSigner()

      let contractAddress = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS
      if (!contractAddress || !ethers.isAddress(contractAddress)) {
        console.warn("Invalid or missing contract address in environment variables. Using fallback address.")
        contractAddress = FALLBACK_CONTRACT_ADDRESS
      }

      const contract = new ethers.Contract(contractAddress, contractABI, signer)
      setContract(contract)

      await refreshBalance()

      toast({
        title: "Success",
        description: "Wallet connected successfully to Scroll Sepolia",
      })
    } catch (error) {
      console.error("Failed to connect wallet:", error)
      toast({
        title: "Error",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnectWallet = () => {
    setAddress(null)
    setIsConnected(false)
    setContract(null)
    setBalance(0)
    setChainId(null)
    toast({ title: "Success", description: "Wallet disconnected" })
  }

  const refreshBalance = async () => {
    if (contract && address) {
      try {
        const balanceWei = await contract.balanceOf(address)
        const balanceETH = ethers.formatEther(balanceWei)
        setBalance(Number.parseFloat(balanceETH))
      } catch (error) {
        console.error("Failed to fetch balance:", error)
      }
    }
  }

  return (
    <Web3Context.Provider
      value={{
        address,
        isConnected,
        isConnecting,
        connectWallet,
        disconnectWallet,
        contract,
        balance,
        refreshBalance,
        chainId,
        isCorrectNetwork,
        switchNetwork,
      }}
    >
      {children}
    </Web3Context.Provider>
  )
}

export function useWeb3() {
  const context = useContext(Web3Context)
  if (context === undefined) {
    throw new Error("useWeb3 must be used within a Web3Provider")
  }
  return context
}

