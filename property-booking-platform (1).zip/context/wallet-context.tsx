"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"

interface WalletContextType {
  balance: number
  addFunds: (amount: number) => void
  withdrawFunds: (amount: number) => void
  transferFunds: (amount: number, to: string) => Promise<boolean>
}

const WalletContext = createContext<WalletContextType | undefined>(undefined)

export function WalletProvider({ children }: { children: ReactNode }) {
  const [balance, setBalance] = useState(0)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (user) {
      // Simulate loading balance from localStorage
      const storedBalance = localStorage.getItem(`wallet_${user.id}`)
      if (storedBalance) {
        setBalance(Number.parseFloat(storedBalance))
      } else {
        // Give new users some initial funds
        const initialBalance = 1000
        setBalance(initialBalance)
        localStorage.setItem(`wallet_${user.id}`, initialBalance.toString())
      }
    } else {
      setBalance(0)
    }
  }, [user])

  const addFunds = (amount: number) => {
    if (!user) return

    const newBalance = balance + amount
    setBalance(newBalance)
    localStorage.setItem(`wallet_${user.id}`, newBalance.toString())

    toast({
      title: "Funds Added",
      description: `${amount} USDT has been added to your wallet.`,
    })
  }

  const withdrawFunds = (amount: number) => {
    if (!user) return

    if (amount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return
    }

    const newBalance = balance - amount
    setBalance(newBalance)
    localStorage.setItem(`wallet_${user.id}`, newBalance.toString())

    toast({
      title: "Funds Withdrawn",
      description: `${amount} USDT has been withdrawn from your wallet.`,
    })
  }

  const transferFunds = async (amount: number, to: string): Promise<boolean> => {
    if (!user) return false

    if (amount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return false
    }

    // Simulate transaction delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const newBalance = balance - amount
    setBalance(newBalance)
    localStorage.setItem(`wallet_${user.id}`, newBalance.toString())

    toast({
      title: "Transaction Successful",
      description: `${amount} USDT has been transferred.`,
    })

    return true
  }

  return (
    <WalletContext.Provider value={{ balance, addFunds, withdrawFunds, transferFunds }}>
      {children}
    </WalletContext.Provider>
  )
}

export function useWallet() {
  const context = useContext(WalletContext)
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider")
  }
  return context
}

