"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Progress } from "@/components/ui/progress"

export default function OrderDetailsPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const { address } = useWeb3()
  const [isCancelling, setIsCancelling] = useState(false)

  const property = properties.find((p) => p.id === params.id)

  if (!property) {
    return (
      <Alert>
        <AlertDescription>Property not found</AlertDescription>
      </Alert>
    )
  }

  const handleCancelOrder = async () => {
    setIsCancelling(true)
    try {
      // Here you would:
      // 1. Call smart contract to return deposit
      // 2. Update order status in database
      // 3. Send cancellation email

      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Order Cancelled",
        description: "Your deposit has been returned to your wallet",
      })

      router.push("/dashboard")
    } catch (error) {
      console.error("Order cancellation failed:", error)
      toast({
        title: "Error",
        description: "Failed to cancel order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsCancelling(false)
    }
  }

  return (
    <div className="container max-w-lg py-10">
      <Card>
        <CardHeader>
          <CardTitle>Investment Order</CardTitle>
          <CardDescription>Current status of your investment</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">{property.name}</h3>
            <p className="text-sm text-muted-foreground">{property.location}</p>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Crowdfunding Progress</span>
              <span>{((property.fundingCurrent / property.fundingGoal) * 100).toFixed(1)}%</span>
            </div>
            <Progress value={(property.fundingCurrent / property.fundingGoal) * 100} />
            <p className="text-xs text-muted-foreground">
              {property.fundingCurrent.toLocaleString()} / {property.fundingGoal.toLocaleString()} ETH raised
            </p>
          </div>

          <div className="rounded-lg bg-muted p-4 space-y-2">
            <div className="flex justify-between">
              <span>Your Deposit</span>
              <span>0.1 ETH</span>
            </div>
            <div className="flex justify-between">
              <span>Status</span>
              <span className="text-green-600">Active</span>
            </div>
          </div>

          <div className="pt-4">
            <Button variant="destructive" className="w-full" onClick={handleCancelOrder} disabled={isCancelling}>
              {isCancelling ? "Processing..." : "Cancel Order & Return Deposit"}
            </Button>
            <p className="text-xs text-muted-foreground text-center mt-2">
              Cancelling will return your deposit to your wallet
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

