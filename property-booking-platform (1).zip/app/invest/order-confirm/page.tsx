"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Progress } from "@/components/ui/progress"

export default function OrderConfirmPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { isConnected, address, ethBalance } = useWeb3()
  const [isProcessing, setIsProcessing] = useState(false)

  const propertyId = searchParams.get("propertyId")
  const amount = searchParams.get("amount")
  const property = properties.find((p) => p.id === propertyId)

  useEffect(() => {
    if (!isConnected || !property || !amount) {
      router.push("/properties")
    }
  }, [isConnected, property, amount, router])

  const handleConfirmOrder = async () => {
    setIsProcessing(true)
    try {
      // Here you would typically call your smart contract
      // For now, we'll just simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Order Confirmed",
        description: `You have successfully invested ${amount} ETH in ${property?.name}`,
      })

      router.push("/dashboard")
    } catch (error) {
      console.error("Order confirmation failed:", error)
      toast({
        title: "Order Failed",
        description: "There was an error processing your order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (!property || !amount) {
    return null
  }

  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100
  const expectedReturn = (Number(amount) * property.expectedRoi) / 100
  const ownershipPercentage = (Number(amount) / property.fundingGoal) * 100

  return (
    <div className="container max-w-2xl py-10">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Confirm Your Investment</CardTitle>
          <CardDescription>Please review your investment details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center space-x-4">
            <div className="relative h-24 w-24">
              <Image
                src={property.image || "/placeholder.svg"}
                alt={property.name}
                fill
                className="object-cover rounded-md"
              />
            </div>
            <div>
              <h3 className="text-lg font-semibold">{property.name}</h3>
              <p className="text-sm text-muted-foreground">{property.location}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Investment Amount</p>
              <p className="text-lg font-semibold">{amount} ETH</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Your Balance</p>
              <p className="text-lg font-semibold">{Number(ethBalance).toFixed(4)} ETH</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Expected Annual Return</p>
              <p className="text-lg font-semibold">
                {expectedReturn.toFixed(4)} ETH ({property.expectedRoi}%)
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Ownership Percentage</p>
              <p className="text-lg font-semibold">{ownershipPercentage.toFixed(2)}%</p>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Funding Progress</p>
            <Progress value={fundingPercentage} className="h-2" />
            <div className="flex justify-between text-sm mt-1">
              <span>{property.fundingCurrent.toLocaleString()} ETH raised</span>
              <span>{property.fundingGoal.toLocaleString()} ETH goal</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.back()} disabled={isProcessing}>
            Modify Order
          </Button>
          <Button onClick={handleConfirmOrder} disabled={isProcessing}>
            {isProcessing ? "Processing..." : "Confirm Investment"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

