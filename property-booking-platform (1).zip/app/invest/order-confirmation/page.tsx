"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"

export default function OrderConfirmationPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { isConnected, address } = useWeb3()
  const [isProcessing, setIsProcessing] = useState(false)

  const propertyId = searchParams.get("propertyId")
  const amount = searchParams.get("amount")
  const property = properties.find((p) => p.id === propertyId)

  useEffect(() => {
    if (!isConnected || !property || !amount) {
      router.push("/properties")
    }
  }, [isConnected, property, amount, router])

  const handleConfirmOrder = async () => {
    setIsProcessing(true)
    try {
      // 这里应该调用智能合约进行实际投资
      // 现在我们只是模拟这个过程
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "订单已确认",
        description: `您已成功下单投资 ${amount} ETH 到 ${property?.name}`,
      })

      router.push("/dashboard")
    } catch (error) {
      console.error("Order confirmation failed:", error)
      toast({
        title: "订单确认失败",
        description: "处理您的订单时出现错误。请稍后再试。",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (!property || !amount) {
    return null
  }

  return (
    <div className="container max-w-lg py-10">
      <Card>
        <CardHeader>
          <CardTitle>确认您的订单</CardTitle>
          <CardDescription>请仔细检查以下订单详情</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium">物业</h3>
            <p>{property.name}</p>
            <p className="text-sm text-muted-foreground">{property.location}</p>
          </div>

          <div>
            <h3 className="font-medium">投资金额</h3>
            <p>{amount} ETH</p>
          </div>

          <div>
            <h3 className="font-medium">预期年回报率</h3>
            <p>{property.expectedRoi}%</p>
          </div>

          <div>
            <h3 className="font-medium">所有权百分比</h3>
            <p>{((Number(amount) / property.fundingGoal) * 100).toFixed(2)}%</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.back()} disabled={isProcessing}>
            返回修改
          </Button>
          <Button onClick={handleConfirmOrder} disabled={isProcessing}>
            {isProcessing ? "处理中..." : "确认订单"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

