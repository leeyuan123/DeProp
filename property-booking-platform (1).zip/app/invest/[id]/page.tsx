"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { MapPin, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import { useWallet } from "@/context/wallet-context"
import { properties } from "@/data/properties"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface InvestPageProps {
  params: {
    id: string
  }
}

export default function InvestPage({ params }: InvestPageProps) {
  const property = properties.find((p) => p.id === params.id)
  const router = useRouter()
  const { user } = useAuth()
  const { balance, transferFunds } = useWallet()
  const { toast } = useToast()

  const [amount, setAmount] = useState(100)
  const [isInvesting, setIsInvesting] = useState(false)

  if (!property) {
    notFound()
  }

  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100
  const minInvestment = 100
  const maxInvestment = Math.min(10000, balance)

  const handleInvest = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please connect your wallet to invest.",
        variant: "destructive",
      })
      return
    }

    if (amount < minInvestment) {
      toast({
        title: "Invalid Amount",
        description: `Minimum investment is ${minInvestment} USDT.`,
        variant: "destructive",
      })
      return
    }

    if (amount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return
    }

    setIsInvesting(true)

    try {
      // Simulate blockchain transaction
      const success = await transferFunds(amount, `property_${property.id}`)

      if (success) {
        toast({
          title: "Investment Successful",
          description: `You have successfully invested ${amount} USDT in ${property.name}.`,
        })

        // Redirect to dashboard after successful investment
        router.push("/dashboard")
      }
    } catch (error) {
      toast({
        title: "Investment Failed",
        description: "There was an error processing your investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsInvesting(false)
    }
  }

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Invest in Property</h1>
          <p className="text-muted-foreground mt-2">Complete your investment in this property</p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="relative h-16 w-16 rounded-md overflow-hidden">
                <Image
                  src={property.image || "/placeholder.svg?height=200&width=200"}
                  alt={property.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <CardTitle>{property.name}</CardTitle>
                <CardDescription className="flex items-center mt-1">
                  <MapPin className="h-3.5 w-3.5 mr-1" />
                  <span>{property.location}</span>
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Funding Progress</span>
                  <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
                </div>
                <Progress value={fundingPercentage} className="h-2" />
                <div className="flex items-center justify-between text-sm">
                  <span>{property.fundingCurrent.toLocaleString()} USDT raised</span>
                  <span>{property.fundingGoal.toLocaleString()} USDT goal</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 py-2">
                <div>
                  <p className="text-sm text-muted-foreground">Expected ROI</p>
                  <p className="font-medium">{property.expectedRoi}% annually</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Min. Investment</p>
                  <p className="font-medium">{minInvestment} USDT</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {!user ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Authentication Required</AlertTitle>
              <AlertDescription>Please connect your wallet to invest in this property.</AlertDescription>
            </Alert>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Investment Amount</CardTitle>
                <CardDescription>Choose how much you want to invest in this property</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Your Balance</span>
                    <span className="font-medium">{balance} USDT</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Investment Amount</span>
                    <span className="font-medium">{amount} USDT</span>
                  </div>

                  <Slider
                    value={[amount]}
                    min={minInvestment}
                    max={maxInvestment}
                    step={100}
                    onValueChange={(value) => setAmount(value[0])}
                    disabled={isInvesting}
                  />

                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      min={minInvestment}
                      max={maxInvestment}
                      disabled={isInvesting}
                    />
                    <span className="font-medium">USDT</span>
                  </div>
                </div>

                <div className="rounded-lg bg-muted p-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Expected Annual Return</span>
                      <span className="font-medium">{((amount * property.expectedRoi) / 100).toFixed(2)} USDT</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Ownership Percentage</span>
                      <span className="font-medium">{((amount / property.fundingGoal) * 100).toFixed(4)}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href={`/properties/${property.id}`}>Cancel</Link>
                </Button>
                <Button onClick={handleInvest} disabled={isInvesting || amount < minInvestment || amount > balance}>
                  {isInvesting ? "Processing..." : "Confirm Investment"}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

