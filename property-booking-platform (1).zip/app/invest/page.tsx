"use client"

import type React from "react"
import { CardFooter } from "@/components/ui/card"
import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { MapPin, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ethers } from "ethers"

export default function InvestPage() {
  const searchParams = useSearchParams()
  const propertyId = searchParams.get("propertyId")
  const router = useRouter()
  const { isConnected, address, contract, balance, refreshBalance } = useWeb3()
  const { toast } = useToast()

  const [selectedProperty, setSelectedProperty] = useState(
    propertyId ? properties.find((p) => p.id === propertyId) : properties[0],
  )
  const [isInvesting, setIsInvesting] = useState(false)

  const minInvestment = 0.0001 // 0.0001 ETH
  const maxInvestment = 0.001 // 0.001 ETH

  const [amount, setAmount] = useState(minInvestment)

  useEffect(() => {
    if (propertyId) {
      const property = properties.find((p) => p.id === propertyId)
      if (property) {
        setSelectedProperty(property)
        setAmount(property.minInvestment)
      }
    }
  }, [propertyId])

  const handleInvest = async () => {
    if (!isConnected || !contract || !selectedProperty) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to invest",
        variant: "destructive",
      })
      return
    }

    if (amount < selectedProperty.minInvestment) {
      toast({
        title: "Invalid amount",
        description: `Minimum investment is ${selectedProperty.minInvestment} USDT`,
        variant: "destructive",
      })
      return
    }

    if (amount > balance) {
      toast({
        title: "Insufficient balance",
        description: "You don't have enough USDT in your wallet",
        variant: "destructive",
      })
      return
    }

    setIsInvesting(true)

    try {
      await contract.invest(address, ethers.parseEther(amount.toString()), selectedProperty.id)

      toast({
        title: "Investment successful",
        description: `You have successfully invested ${amount} USDT in ${selectedProperty.name}`,
      })

      await refreshBalance()
      router.push("/dashboard")
    } catch (error) {
      console.error("Investment failed:", error)
      toast({
        title: "Investment failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsInvesting(false)
    }
  }

  if (!selectedProperty) {
    return (
      <div className="container py-10">
        <div className="max-w-3xl mx-auto">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>Property not found. Please select a valid property.</AlertDescription>
          </Alert>
          <div className="mt-4">
            <Button asChild>
              <Link href="/properties">Browse Properties</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const handleSliderChange = (value: number[]) => {
    setAmount(value[0])
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value)
    if (!isNaN(value)) {
      setAmount(Math.min(Math.max(value, minInvestment), maxInvestment))
    }
  }

  const totalFundingAmount = selectedProperty.fundingGoal
  const fundingCurrent = selectedProperty.fundingCurrent
  const fundingPercentage = (fundingCurrent / totalFundingAmount) * 100

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Invest in {selectedProperty.name}</h1>
          <p className="text-muted-foreground mt-2">Complete your investment in this unique property</p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="relative h-48 w-full rounded-md overflow-hidden">
                <Image
                  src={selectedProperty.image || "/placeholder.svg"}
                  alt={selectedProperty.name}
                  fill
                  className="object-cover"
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <h2 className="text-2xl font-semibold">{selectedProperty.name}</h2>
              <div className="flex items-center text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{selectedProperty.location}</span>
              </div>
              <p>{selectedProperty.description}</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Funding Progress</span>
                  <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
                </div>
                <Progress value={fundingPercentage} className="h-2" />
                <div className="flex items-center justify-between text-sm">
                  <span>{fundingCurrent.toFixed(6)} ETH raised</span>
                  <span>{totalFundingAmount.toFixed(6)} ETH goal</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 py-2">
                <div>
                  <p className="text-sm text-muted-foreground">Expected ROI</p>
                  <p className="font-medium">{selectedProperty.expectedRoi}% annually</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Min. Investment</p>
                  <p className="font-medium">{minInvestment} ETH</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {!isConnected ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Wallet not connected</AlertTitle>
              <AlertDescription>Please connect your wallet to invest in this property.</AlertDescription>
            </Alert>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Investment Amount</CardTitle>
                <CardDescription>Choose how much you want to invest in this property</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Your Balance</span>
                    <span className="font-medium">{balance} ETH</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Investment Amount</span>
                    <span className="font-medium">{amount} ETH</span>
                  </div>

                  <Slider
                    value={[amount]}
                    min={minInvestment}
                    max={maxInvestment}
                    step={0.0001}
                    onValueChange={handleSliderChange}
                    className="w-full"
                    disabled={isInvesting}
                  />

                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      value={amount}
                      onChange={handleInputChange}
                      min={minInvestment}
                      max={maxInvestment}
                      step={0.0001}
                      className="w-full"
                      disabled={isInvesting}
                    />
                    <span className="font-medium">ETH</span>
                  </div>

                  <div className="rounded-lg bg-muted p-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Expected Annual Return</span>
                        <span className="font-medium">
                          {((amount * selectedProperty.expectedRoi) / 100).toFixed(6)} ETH
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Ownership Percentage</span>
                        <span className="font-medium">
                          {((amount / selectedProperty.fundingGoal) * 100).toFixed(4)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <CardFooter className="flex justify-between">
                  <Button variant="outline" asChild>
                    <Link href="/properties">Cancel</Link>
                  </Button>
                  <Button onClick={handleInvest} disabled={isInvesting} variant="cta">
                    {isInvesting ? "Processing..." : "Confirm Investment"}
                  </Button>
                </CardFooter>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

