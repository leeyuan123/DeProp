"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useWeb3 } from "@/context/web3-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ProtectedRoute } from "@/components/protected-route"
import { InvestmentActions } from "@/components/investment-actions"
import { SharedWalletInfo } from "@/components/shared-wallet-info"
import { ProposalVoting } from "@/components/proposal-voting"
import { useToast } from "@/components/ui/use-toast"
import { ethers } from "ethers"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getOrderStatusString } from "@/lib/contract-config"
import { NetworkAlert } from "@/components/network-alert"

interface Order {
  id: string
  projectName: string
  amountInvested: number
  status: "Pending" | "Confirmed" | "Cancelled" | "Completed"
  sharedWalletBalance: number
  percentageOwnership: number
  estimatedAnnualReturn: number
}

export default function OrderPage() {
  const router = useRouter()
  const { isConnected, address, contract, isMockData, isCorrectNetwork, switchNetwork, CONTRACT_ADDRESS } = useWeb3()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (contract) {
      fetchOrders()
    } else {
      setIsLoading(false)
      setError("Contract not available")
    }
  }, [contract, isCorrectNetwork])

  // Update the fetchOrders function to better handle errors
  const fetchOrders = async () => {
    setIsLoading(true)
    setError(null)
    try {
      console.log("Fetching orders...")

      // For real contract
      if (!isMockData) {
        try {
          // Get the next order ID to know how many orders exist
          const nextOrderId = await contract.nextOrderId()
          const orderIds = []

          // Create an array of order IDs from 1 to nextOrderId-1
          for (let i = 1; i < Number(nextOrderId); i++) {
            orderIds.push(i.toString())
          }

          // Filter orders that belong to the current user
          const fetchedOrders = await Promise.all(
            orderIds.map(async (id: string) => {
              try {
                const orderData = await contract.orders(id)

                // Only include orders that belong to the current user
                if (orderData.buyer.toLowerCase() === address?.toLowerCase()) {
                  // Get project data
                  const projectData = await contract.projects(orderData.projectId)

                  // Calculate percentage ownership
                  const percentageOwnership =
                    orderData.amount > 0 && projectData.totalInvestment > 0
                      ? (Number(orderData.amount) / Number(projectData.totalInvestment)) * 100
                      : 0

                  // Estimate annual return (mock calculation - replace with actual logic)
                  const estimatedAnnualReturn = Number(orderData.amount) * 0.08 // 8% annual return

                  return {
                    id: id,
                    projectName: `Project ${orderData.projectId}`, // Replace with actual project name if available
                    amountInvested: Number(ethers.formatEther(orderData.amount.toString())),
                    status: getOrderStatusString(Number(orderData.status)),
                    sharedWalletBalance: Number(ethers.formatEther(projectData.totalInvestment.toString())),
                    percentageOwnership,
                    estimatedAnnualReturn: Number(ethers.formatEther(estimatedAnnualReturn.toString())),
                  }
                }
                return null
              } catch (err) {
                console.error(`Error fetching order ${id}:`, err)
                return null
              }
            }),
          )

          // Filter out null values (orders that don't belong to the user or had errors)
          const userOrders = fetchedOrders.filter((order) => order !== null) as Order[]
          setOrders(userOrders)
        } catch (err) {
          console.error("Error in contract interaction:", err)
          throw new Error("Failed to interact with the contract. Please check your network connection.")
        }
      }
      // For mock contract
      else {
        const orderIds = await contract.getOrderIds(address)
        const fetchedOrders = await Promise.all(
          orderIds.map(async (id: string) => {
            const orderData = await contract.getOrder(id)
            return {
              id,
              projectName: orderData.projectName,
              amountInvested: Number(ethers.formatEther(orderData.amountInvested.toString())),
              status: orderData.status,
              sharedWalletBalance: Number(ethers.formatEther(orderData.sharedWalletBalance.toString())),
              percentageOwnership: Number(orderData.percentageOwnership),
              estimatedAnnualReturn: Number(ethers.formatEther(orderData.estimatedAnnualReturn.toString())),
            }
          }),
        )
        setOrders(fetchedOrders)
      }

      console.log("Orders fetched:", orders)
    } catch (error) {
      console.error("Failed to fetch orders:", error)
      setError("Failed to load orders. Please try again.")
      toast({
        title: "Error",
        description: "Failed to load orders. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleConfirmInvestment = async (orderId: string) => {
    if (!isCorrectNetwork) {
      toast({
        title: "Wrong Network",
        description: "Please switch to the Scroll Sepolia testnet to perform this action.",
        variant: "destructive",
      })
      await switchNetwork()
      return
    }

    try {
      // Use direct MetaMask API to avoid ENS resolution
      const functionSignature = "confirmOrder(uint256)"
      const functionSelector = ethers.id(functionSignature).substring(0, 10)
      const encodedOrderId = ethers.zeroPadValue(ethers.toBeHex(Number(orderId)), 32)
      const data = functionSelector + encodedOrderId.substring(2)

      await window.ethereum.request({
        method: "eth_sendTransaction",
        params: [
          {
            from: address,
            to: CONTRACT_ADDRESS,
            data: data,
          },
        ],
      })

      toast({
        title: "Investment Confirmed",
        description: "Your investment has been confirmed and funds transferred to the shared wallet.",
      })
      fetchOrders() // Refresh orders after confirmation
    } catch (error) {
      console.error("Failed to confirm investment:", error)
      toast({
        title: "Error",
        description: "Failed to confirm investment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateInvestment = async (orderId: string, action: "increase" | "decrease", amount: number) => {
    if (!isCorrectNetwork) {
      toast({
        title: "Wrong Network",
        description: "Please switch to the Scroll Sepolia testnet to perform this action.",
        variant: "destructive",
      })
      await switchNetwork()
      return
    }

    try {
      // Get current order data
      const orderData = await contract.orders(orderId)
      const currentAmount = orderData.amount

      // Calculate new amount based on action
      let newAmount
      const amountInWei = ethers.parseEther(amount.toString())

      if (action === "increase") {
        newAmount = currentAmount + amountInWei

        // Function signature for adjustInvestment(uint256,uint256)
        const functionSignature = "adjustInvestment(uint256,uint256)"
        const functionSelector = ethers.id(functionSignature).substring(0, 10)
        const encodedOrderId = ethers.zeroPadValue(ethers.toBeHex(Number(orderId)), 32)
        const encodedNewAmount = ethers.zeroPadValue(ethers.toBeHex(newAmount), 32)
        const data = functionSelector + encodedOrderId.substring(2) + encodedNewAmount.substring(2)

        // For increase, we need to send additional ETH
        await window.ethereum.request({
          method: "eth_sendTransaction",
          params: [
            {
              from: address,
              to: CONTRACT_ADDRESS,
              value: ethers.toBeHex(amountInWei),
              data: data,
            },
          ],
        })
      } else {
        // Ensure we don't go below zero
        newAmount = currentAmount - amountInWei
        if (newAmount < 0) {
          throw new Error("Cannot decrease below zero")
        }

        // Function signature for adjustInvestment(uint256,uint256)
        const functionSignature = "adjustInvestment(uint256,uint256)"
        const functionSelector = ethers.id(functionSignature).substring(0, 10)
        const encodedOrderId = ethers.zeroPadValue(ethers.toBeHex(Number(orderId)), 32)
        const encodedNewAmount = ethers.zeroPadValue(ethers.toBeHex(newAmount), 32)
        const data = functionSelector + encodedOrderId.substring(2) + encodedNewAmount.substring(2)

        await window.ethereum.request({
          method: "eth_sendTransaction",
          params: [
            {
              from: address,
              to: CONTRACT_ADDRESS,
              data: data,
            },
          ],
        })
      }

      toast({
        title: "Investment Updated",
        description: `Your investment has been ${action}d by ${amount} ETH.`,
      })
      fetchOrders() // Refresh orders after update
    } catch (error) {
      console.error("Failed to update investment:", error)
      toast({
        title: "Error",
        description: "Failed to update investment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleWithdrawInvestment = async (orderId: string) => {
    if (!isCorrectNetwork) {
      toast({
        title: "Wrong Network",
        description: "Please switch to the Scroll Sepolia testnet to perform this action.",
        variant: "destructive",
      })
      await switchNetwork()
      return
    }

    try {
      // Function signature for withdrawInvestment(uint256)
      const functionSignature = "withdrawInvestment(uint256)"
      const functionSelector = ethers.id(functionSignature).substring(0, 10)
      const encodedOrderId = ethers.zeroPadValue(ethers.toBeHex(Number(orderId)), 32)
      const data = functionSelector + encodedOrderId.substring(2)

      await window.ethereum.request({
        method: "eth_sendTransaction",
        params: [
          {
            from: address,
            to: CONTRACT_ADDRESS,
            data: data,
          },
        ],
      })

      toast({
        title: "Investment Withdrawn",
        description: "Your investment has been withdrawn successfully.",
      })
      fetchOrders() // Refresh orders after withdrawal
    } catch (error) {
      console.error("Failed to withdraw investment:", error)
      toast({
        title: "Error",
        description: "Failed to withdraw investment. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return <div>Loading orders... Please wait.</div>
  }

  if (error) {
    return <div>Error: {error}</div>
  }

  return (
    <ProtectedRoute>
      <div className="container py-10">
        <NetworkAlert isCorrectNetwork={isCorrectNetwork} switchNetwork={switchNetwork} />

        {isMockData && (
          <Alert className="mb-6">
            <AlertTitle>Mock Data</AlertTitle>
            <AlertDescription>
              You are currently viewing mock data. No real blockchain interactions are taking place.
            </AlertDescription>
          </Alert>
        )}

        <h1 className="text-3xl font-bold mb-6">Investment Orders</h1>
        {orders.length === 0 ? (
          <div>No orders found.</div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Investment ID</TableHead>
                  <TableHead>Project Name</TableHead>
                  <TableHead>Amount Invested</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell>{order.id}</TableCell>
                    <TableCell>{order.projectName}</TableCell>
                    <TableCell>{order.amountInvested} ETH</TableCell>
                    <TableCell>{order.status}</TableCell>
                    <TableCell>
                      <InvestmentActions
                        orderId={order.id}
                        status={order.status}
                        onConfirm={handleConfirmInvestment}
                        onUpdate={handleUpdateInvestment}
                        onWithdraw={handleWithdrawInvestment}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {orders.map((order) => (
              <div key={order.id} className="mt-8">
                <SharedWalletInfo
                  orderId={order.id}
                  projectName={order.projectName}
                  sharedWalletBalance={order.sharedWalletBalance}
                  percentageOwnership={order.percentageOwnership}
                  estimatedAnnualReturn={order.estimatedAnnualReturn}
                />
                {order.status === "Confirmed" && (
                  <ProposalVoting
                    orderId={order.id}
                    onProposalSubmit={async (proposal) => {
                      try {
                        // In a real implementation, this would call a contract method
                        // For now, we'll just show a success message
                        toast({
                          title: "Proposal Submitted",
                          description: "Your proposal has been submitted successfully.",
                        })
                        fetchOrders() // Refresh orders after proposal submission
                      } catch (error) {
                        console.error("Failed to submit proposal:", error)
                        toast({
                          title: "Error",
                          description: "Failed to submit proposal. Please try again.",
                          variant: "destructive",
                        })
                      }
                    }}
                    onVote={async (proposalId) => {
                      try {
                        // In a real implementation, this would call a contract method
                        // For now, we'll just show a success message
                        toast({
                          title: "Vote Recorded",
                          description: "Your vote has been recorded successfully.",
                        })
                        fetchOrders() // Refresh orders after voting
                      } catch (error) {
                        console.error("Failed to vote on proposal:", error)
                        toast({
                          title: "Error",
                          description: "Failed to record your vote. Please try again.",
                          variant: "destructive",
                        })
                      }
                    }}
                  />
                )}
              </div>
            ))}
          </>
        )}
      </div>
    </ProtectedRoute>
  )
}

