"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { MapPin, Calendar, Users, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import { useWallet } from "@/context/wallet-context"
import { properties } from "@/data/properties"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, addDays, differenceInDays } from "date-fns"

interface BookPageProps {
  params: {
    id: string
  }
}

export default function BookPage({ params }: BookPageProps) {
  const property = properties.find((p) => p.id === params.id)
  const router = useRouter()
  const { user } = useAuth()
  const { balance, transferFunds } = useWallet()
  const { toast } = useToast()

  const [checkIn, setCheckIn] = useState<Date | undefined>(addDays(new Date(), 1))
  const [checkOut, setCheckOut] = useState<Date | undefined>(addDays(new Date(), 5))
  const [guests, setGuests] = useState(1)
  const [isBooking, setIsBooking] = useState(false)

  if (!property) {
    notFound()
  }

  if (property.type !== "residential" || property.pricePerNight === 0) {
    router.push(`/properties/${property.id}`)
    return null
  }

  const nights = checkIn && checkOut ? differenceInDays(checkOut, checkIn) : 0
  const totalPrice = nights * property.pricePerNight

  const handleBook = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please connect your wallet to book a stay.",
        variant: "destructive",
      })
      return
    }

    if (!checkIn || !checkOut) {
      toast({
        title: "Invalid Dates",
        description: "Please select check-in and check-out dates.",
        variant: "destructive",
      })
      return
    }

    if (nights <= 0) {
      toast({
        title: "Invalid Dates",
        description: "Check-out date must be after check-in date.",
        variant: "destructive",
      })
      return
    }

    if (guests < 1 || guests > property.capacity) {
      toast({
        title: "Invalid Guests",
        description: `This property can accommodate up to ${property.capacity} guests.`,
        variant: "destructive",
      })
      return
    }

    if (totalPrice > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return
    }

    setIsBooking(true)

    try {
      // Simulate blockchain transaction
      const success = await transferFunds(totalPrice, `booking_${property.id}`)

      if (success) {
        toast({
          title: "Booking Successful",
          description: `You have successfully booked ${property.name} for ${nights} nights.`,
        })

        // Redirect to dashboard after successful booking
        router.push("/dashboard")
      }
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsBooking(false)
    }
  }

  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Book a Stay</h1>
          <p className="text-muted-foreground mt-2">Complete your booking for this property</p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="relative h-16 w-16 rounded-md overflow-hidden">
                <Image
                  src={property.image || "/placeholder.svg?height=200&width=200"}
                  alt={property.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <CardTitle>{property.name}</CardTitle>
                <CardDescription className="flex items-center mt-1">
                  <MapPin className="h-3.5 w-3.5 mr-1" />
                  <span>{property.location}</span>
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 py-2">
                <div>
                  <p className="text-sm text-muted-foreground">Price per night</p>
                  <p className="font-medium">{property.pricePerNight} USDT</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Max Capacity</p>
                  <p className="font-medium">{property.capacity} guests</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {!user ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Authentication Required</AlertTitle>
              <AlertDescription>Please connect your wallet to book this property.</AlertDescription>
            </Alert>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Booking Details</CardTitle>
                <CardDescription>Select your check-in and check-out dates and number of guests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Check-in Date</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <Calendar className="mr-2 h-4 w-4" />
                          {checkIn ? format(checkIn, "PPP") : <span>Select date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={checkIn}
                          onSelect={setCheckIn}
                          initialFocus
                          disabled={(date) => date < new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Check-out Date</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <Calendar className="mr-2 h-4 w-4" />
                          {checkOut ? format(checkOut, "PPP") : <span>Select date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={checkOut}
                          onSelect={setCheckOut}
                          initialFocus
                          disabled={(date) => date < (checkIn || new Date())}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Number of Guests</label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                      min={1}
                      max={property.capacity}
                      disabled={isBooking}
                    />
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    This property can accommodate up to {property.capacity} guests.
                  </p>
                </div>

                <div className="rounded-lg bg-muted p-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">
                        {property.pricePerNight} USDT × {nights} nights
                      </span>
                      <span className="font-medium">{totalPrice} USDT</span>
                    </div>
                    <div className="flex items-center justify-between font-medium pt-2 border-t">
                      <span>Total</span>
                      <span>{totalPrice} USDT</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href={`/properties/${property.id}`}>Cancel</Link>
                </Button>
                <Button
                  onClick={handleBook}
                  disabled={
                    isBooking ||
                    !checkIn ||
                    !checkOut ||
                    nights <= 0 ||
                    guests < 1 ||
                    guests > property.capacity ||
                    totalPrice > balance
                  }
                >
                  {isBooking ? "Processing..." : "Confirm Booking"}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

