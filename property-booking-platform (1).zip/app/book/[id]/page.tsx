"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { MapPin, Calendar, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, addDays, differenceInDays } from "date-fns"
import { ProtectedRoute } from "@/components/protected-route"

interface BookPageProps {
  params: {
    id: string
  }
}

export default function BookPage({ params }: BookPageProps) {
  const property = properties.find((p) => p.id === params.id)
  const router = useRouter()
  const { isConnected, ethBalance } = useWeb3()
  const { toast } = useToast()

  const [checkIn, setCheckIn] = useState<Date | undefined>(addDays(new Date(), 1))
  const [checkOut, setCheckOut] = useState<Date | undefined>(addDays(new Date(), 5))
  const [guests, setGuests] = useState(1)
  const [isBooking, setIsBooking] = useState(false)

  useEffect(() => {
    if (!property) {
      notFound()
    }
  }, [property])

  if (!property) {
    return null
  }

  // Fix the nights calculation to handle 1-day stays correctly
  const nights = checkIn && checkOut ? Math.max(1, differenceInDays(checkOut, checkIn)) : 0
  const totalPrice = nights * property.pricePerNight

  const handleBook = async () => {
    if (!isConnected) {
      toast({
        title: "Authentication Required",
        description: "Please connect your wallet to book a stay.",
        variant: "destructive",
      })
      return
    }

    if (!checkIn || !checkOut) {
      toast({
        title: "Invalid Dates",
        description: "Please select check-in and check-out dates.",
        variant: "destructive",
      })
      return
    }

    if (nights <= 0) {
      toast({
        title: "Invalid Dates",
        description: "Check-out date must be after check-in date.",
        variant: "destructive",
      })
      return
    }

    if (guests < 1 || guests > property.capacity) {
      toast({
        title: "Invalid Guests",
        description: `This property can accommodate up to ${property.capacity} guests.`,
        variant: "destructive",
      })
      return
    }

    if (totalPrice > Number(ethBalance)) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough ETH in your wallet.",
        variant: "destructive",
      })
      return
    }

    setIsBooking(true)

    try {
      // Simulate blockchain transaction
      const success = true // In a real app, this would be the result of the blockchain transaction

      if (success) {
        toast({
          title: "Booking Successful",
          description: `You have successfully booked ${property.name} for ${nights} nights.`,
        })

        // Redirect to dashboard after successful booking
        router.push("/dashboard")
      }
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsBooking(false)
    }
  }

  return (
    <ProtectedRoute>
      <div className="container py-10">
        <h1 className="text-3xl font-bold mb-6">Book Your Stay at {property.name}</h1>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader className="p-0">
              <div className="relative h-64 w-full">
                <Image
                  src={property.image || "/placeholder.svg?height=400&width=600"}
                  alt={property.name}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold">{property.name}</h2>
              <div className="flex items-center text-muted-foreground mt-1 mb-4">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{property.location}</span>
              </div>
              <p>{property.description}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Booking Details</CardTitle>
              <CardDescription>Select your dates and number of guests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Check-in Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal mt-2">
                        <Calendar className="mr-2 h-4 w-4" />
                        {checkIn ? format(checkIn, "PPP") : <span>Select date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={checkIn}
                        onSelect={setCheckIn}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <label className="text-sm font-medium">Check-out Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal mt-2">
                        <Calendar className="mr-2 h-4 w-4" />
                        {checkOut ? format(checkOut, "PPP") : <span>Select date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={checkOut}
                        onSelect={setCheckOut}
                        initialFocus
                        disabled={(date) => date < (checkIn || new Date())}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Number of Guests</label>
                <div className="flex items-center space-x-2 mt-2">
                  <Input
                    type="number"
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                    min={1}
                    max={property.capacity}
                  />
                  <Users className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  This property can accommodate up to {property.capacity} guests.
                </p>
              </div>

              {checkIn && checkOut && (
                <div className="rounded-lg bg-muted p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Number of Nights</span>
                      <span>{nights}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Price per Night</span>
                      <span>{property.pricePerNight} ETH</span>
                    </div>
                    <div className="flex justify-between font-medium pt-2 border-t">
                      <span>Total Price</span>
                      <span>{totalPrice} ETH</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/book">Back</Link>
              </Button>
              <Button
                onClick={handleBook}
                disabled={
                  isBooking ||
                  !checkIn ||
                  !checkOut ||
                  nights <= 0 ||
                  guests < 1 ||
                  guests > property.capacity ||
                  !isConnected
                }
              >
                {isBooking ? "Processing..." : "Confirm Booking"}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}

