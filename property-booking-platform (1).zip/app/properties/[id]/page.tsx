import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { MapPin, Users, Bed, Bath, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { properties } from "@/data/properties"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface PropertyPageProps {
  params: {
    id: string
  }
}

export default function PropertyPage({ params }: PropertyPageProps) {
  const property = properties.find((p) => p.id === params.id)

  if (!property) {
    notFound()
  }

  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100

  return (
    <div className="container py-10">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">{property.name}</h1>
              <div className="flex items-center mt-2 text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{property.location}</span>
              </div>
            </div>

            <div className="aspect-video relative rounded-lg overflow-hidden">
              <Image
                src={property.images[0] || "/placeholder.svg?height=600&width=1200"}
                alt={property.name}
                fill
                className="object-cover"
              />
            </div>

            <div className="grid grid-cols-4 gap-2">
              {property.images.slice(1).map((image, index) => (
                <div key={index} className="aspect-video relative rounded-lg overflow-hidden">
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${property.name} - Image ${index + 2}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>

            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="amenities">Amenities</TabsTrigger>
                <TabsTrigger value="investment">Investment Details</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div>
                  <h2 className="text-xl font-semibold mb-2">Description</h2>
                  <p className="text-muted-foreground">{property.description}</p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-4">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Capacity</p>
                      <p className="font-medium">{property.capacity} guests</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Bed className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Bedrooms</p>
                      <p className="font-medium">{property.bedrooms}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Bath className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Bathrooms</p>
                      <p className="font-medium">{property.bathrooms}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="amenities" className="space-y-4">
                <h2 className="text-xl font-semibold mb-2">Amenities</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {property.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-primary" />
                      <span>{amenity}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="investment" className="space-y-4">
                <h2 className="text-xl font-semibold mb-2">Investment Details</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm text-muted-foreground">Funding Goal</p>
                    <p className="font-medium text-lg">{property.fundingGoal.toLocaleString()} USDT</p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground">Expected ROI</p>
                    <p className="font-medium text-lg">{property.expectedRoi}% annually</p>
                  </div>

                  <div className="sm:col-span-2 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Funding Progress</span>
                      <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
                    </div>
                    <Progress value={fundingPercentage} className="h-2" />
                    <div className="flex items-center justify-between text-sm">
                      <span>{property.fundingCurrent.toLocaleString()} USDT raised</span>
                      <span>{(property.fundingGoal - property.fundingCurrent).toLocaleString()} USDT remaining</span>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-20 space-y-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Badge variant={property.type === "residential" ? "default" : "secondary"}>
                    {property.type === "residential" ? "Residential" : "Commercial"}
                  </Badge>
                  {property.pricePerNight > 0 && (
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Price per night</p>
                      <p className="font-semibold">{property.pricePerNight} USDT</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Funding Progress</span>
                    <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
                  </div>
                  <Progress value={fundingPercentage} className="h-2" />
                  <div className="flex items-center justify-between text-sm">
                    <span>{property.fundingCurrent.toLocaleString()} USDT</span>
                    <span>{property.fundingGoal.toLocaleString()} USDT</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Min. Investment</p>
                    <p className="font-medium">100 USDT</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Expected ROI</p>
                    <p className="font-medium">{property.expectedRoi}%</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button asChild className="w-full">
                    <Link href={`/invest/${property.id}`}>Invest Now</Link>
                  </Button>

                  {property.type === "residential" && property.pricePerNight > 0 && (
                    <Button asChild variant="outline" className="w-full">
                      <Link href={`/book/${property.id}`}>Book a Stay</Link>
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

