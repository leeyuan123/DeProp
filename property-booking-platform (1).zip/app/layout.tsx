import type React from "react"
import "@/styles/globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Web3Provider } from "@/context/web3-context"
import { AuthProvider } from "@/context/auth-context"
import { WalletProvider } from "@/context/wallet-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DeProp - Decentralized Property Booking",
  description: "Invest in properties and book stays using USDT",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <Web3Provider>
            <WalletProvider>
              {children}
              <Toaster />
            </WalletProvider>
          </Web3Provider>
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'