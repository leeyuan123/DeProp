"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { WalletIcon, Plus, ArrowUpRight, ArrowDownLeft, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/context/auth-context"
import { useWallet } from "@/context/wallet-context"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"

interface Transaction {
  id: string
  type: "deposit" | "withdrawal" | "investment" | "booking"
  amount: number
  date: Date
  description: string
}

export default function WalletPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { balance, addFunds, withdrawFunds } = useWallet()
  const { toast } = useToast()
  const { address, isConnected, isConnecting, connectWallet } = useWeb3()

  const [depositAmount, setDepositAmount] = useState(100)
  const [withdrawAmount, setWithdrawAmount] = useState(100)
  const [isProcessing, setIsProcessing] = useState(false)

  // Mock transactions
  const transactions: Transaction[] = [
    {
      id: "1",
      type: "deposit",
      amount: 1000,
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      description: "Initial deposit",
    },
    {
      id: "2",
      type: "investment",
      amount: -500,
      date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      description: "Investment in Luxury Beachfront Villa",
    },
    {
      id: "3",
      type: "booking",
      amount: -1500,
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      description: "Booking at Downtown Luxury Apartment",
    },
    {
      id: "4",
      type: "deposit",
      amount: 1000,
      date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      description: "Added funds",
    },
  ]

  const handleDeposit = () => {
    if (depositAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a positive amount.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate transaction delay
    setTimeout(() => {
      addFunds(depositAmount)
      setIsProcessing(false)
    }, 1500)
  }

  const handleWithdraw = () => {
    if (withdrawAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a positive amount.",
        variant: "destructive",
      })
      return
    }

    if (withdrawAmount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate transaction delay
    setTimeout(() => {
      withdrawFunds(withdrawAmount)
      setIsProcessing(false)
    }, 1500)
  }

  const handleConnect = async () => {
    try {
      await connectWallet()
    } catch (error) {
      console.error("Failed to connect wallet:", error)
      toast({
        title: "Error",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (!user) {
    router.push("/")
    return null
  }

  return (
    <div className="container py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Wallet</h1>
        <p className="text-muted-foreground mt-1">Manage your USDT balance</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <WalletIcon className="mr-2 h-5 w-5" />
                Your Balance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{balance} USDT</div>
              <p className="text-sm text-muted-foreground mt-2">
                Your simulated USDT balance for investing and booking
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="deposit" className="space-y-4">
            <TabsList className="grid grid-cols-2">
              <TabsTrigger value="deposit">Deposit</TabsTrigger>
              <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
            </TabsList>

            <TabsContent value="deposit">
              <Card>
                <CardHeader>
                  <CardTitle>Add Funds</CardTitle>
                  <CardDescription>Add USDT to your wallet for investing and booking</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Amount (USDT)</label>
                      <div className="flex items-center space-x-2">
                        <Input
                          type="number"
                          value={depositAmount}
                          onChange={(e) => setDepositAmount(Number(e.target.value))}
                          min={1}
                          disabled={isProcessing}
                        />
                        <span className="font-medium">USDT</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleDeposit} disabled={isProcessing || depositAmount <= 0} className="w-full">
                    {isProcessing ? (
                      <>
                        <Clock className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Funds
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="withdraw">
              <Card>
                <CardHeader>
                  <CardTitle>Withdraw Funds</CardTitle>
                  <CardDescription>Withdraw USDT from your wallet</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Amount (USDT)</label>
                      <div className="flex items-center space-x-2">
                        <Input
                          type="number"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                          min={1}
                          max={balance}
                          disabled={isProcessing}
                        />
                        <span className="font-medium">USDT</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    onClick={handleWithdraw}
                    disabled={isProcessing || withdrawAmount <= 0 || withdrawAmount > balance}
                    className="w-full"
                  >
                    {isProcessing ? (
                      <>
                        <Clock className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <ArrowUpRight className="mr-2 h-4 w-4" />
                        Withdraw Funds
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
          <div className="space-y-4 mt-6">
            <Button onClick={handleConnect} disabled={isConnected || isConnecting}>
              {isConnected
                ? `Connected: ${address?.slice(0, 6)}...${address?.slice(-4)}`
                : isConnecting
                  ? "Connecting..."
                  : "Connect Wallet"}
            </Button>
            {isConnected && (
              <p className="text-green-600">Your wallet is connected. You can now invest or book properties.</p>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Your recent wallet activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 rounded-lg border">
                    <div className="flex items-center gap-4">
                      <div
                        className={`h-10 w-10 rounded-full flex items-center justify-center ${
                          transaction.amount > 0 ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                        }`}
                      >
                        {transaction.amount > 0 ? (
                          <ArrowDownLeft className="h-5 w-5" />
                        ) : (
                          <ArrowUpRight className="h-5 w-5" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {transaction.date.toLocaleDateString()} at {transaction.date.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <div className={`font-semibold ${transaction.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                      {transaction.amount > 0 ? "+" : ""}
                      {transaction.amount} USDT
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

