import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { products } from "@/data/products"
import { Navbar } from "@/components/navbar"
import { Wallet, Building, Calendar } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero Section with Background Image */}
      <section className="relative flex items-center justify-center h-[70vh] text-white">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202024-12-26%2017.21.52%20-%20A%20zoomed-in%20interior%20view%20of%20a%20modular%2C%20adaptive%20living%20space%20in%20a%20futuristic%20coastal%20community%20inspired%20by%20Tomorrowland%20and%20Avatar.%20The%20space%20showcas-uTru89Ga7c9WjvxnPfGkuF3HyUpsB4.jpeg"
          alt="Future of living"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative z-10 text-center px-4 max-w-3xl">
          <h1 className="text-5xl font-bold mb-6 leading-tight">Welcome to the Future of Property Investment</h1>
          <p className="text-xl mb-8 text-gray-200">Invest in premium properties and book luxurious stays using ETH</p>
          <div className="flex justify-center space-x-4">
            <Button
              asChild
              size="lg"
              variant="default"
              className="bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-6 rounded-full transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <Link href="/invest">Start Investing</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white/10 text-white border-white hover:bg-white/20 font-semibold py-3 px-6 rounded-full transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <Link href="/book">Book a Stay</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Available Products Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-4xl font-bold mb-3 text-center">Available Products</h2>
        <p className="text-xl text-muted-foreground mb-12 text-center">Exclusive properties ready for investment</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-secondary py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-primary text-primary-foreground rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Wallet className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">1. Connect Your Wallet</h3>
              <p className="text-muted-foreground">Link your crypto wallet to start investing or booking stays.</p>
            </div>
            <div className="text-center">
              <div className="bg-primary text-primary-foreground rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Building className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">2. Choose Your Action</h3>
              <p className="text-muted-foreground">Decide whether you want to invest in a property or book a stay.</p>
            </div>
            <div className="text-center">
              <div className="bg-primary text-primary-foreground rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Calendar className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">3. Confirm and Enjoy</h3>
              <p className="text-muted-foreground">
                Complete your transaction and enjoy the benefits of decentralized property management.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

