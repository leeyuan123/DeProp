# DeProp - Decentralized Property Booking Platform

This is an MVP for a decentralized property booking platform that allows users to invest in properties using USDT and book stays.

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Create a `.env.local` file in the root directory and add:

