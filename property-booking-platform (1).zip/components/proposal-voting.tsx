"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ProposalVotingProps {
  orderId: string
  onProposalSubmit: (proposal: { shippingAddress: string; buildingUse: string; rentalPrice: string }) => Promise<void>
  onVote: (proposalId: string) => Promise<void>
}

export function ProposalVoting({ orderId, onProposalSubmit, onVote }: ProposalVotingProps) {
  const [shippingAddress, setShippingAddress] = useState("")
  const [buildingUse, setBuildingUse] = useState("")
  const [rentalPrice, setRentalPrice] = useState("")
  const [selectedProposal, setSelectedProposal] = useState("")
  const [consensusProgress, setConsensusProgress] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isVoting, setIsVoting] = useState(false)

  const handleSubmitProposal = async () => {
    setIsSubmitting(true)
    try {
      await onProposalSubmit({ shippingAddress, buildingUse, rentalPrice })
      setShippingAddress("")
      setBuildingUse("")
      setRentalPrice("")
    } catch (error) {
      console.error("Failed to submit proposal:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleVote = async () => {
    setIsVoting(true)
    try {
      await onVote(selectedProposal)
      setConsensusProgress(Math.min(consensusProgress + 20, 100))
    } catch (error) {
      console.error("Failed to vote:", error)
    } finally {
      setIsVoting(false)
    }
  }

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle>Proposal Voting</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <Input
            placeholder="Shipping Address"
            value={shippingAddress}
            onChange={(e) => setShippingAddress(e.target.value)}
          />
          <RadioGroup value={buildingUse} onValueChange={setBuildingUse}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="rental" id="rental" />
              <Label htmlFor="rental">Rental</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="personal" id="personal" />
              <Label htmlFor="personal">Personal Use</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="resale" id="resale" />
              <Label htmlFor="resale">Resale</Label>
            </div>
          </RadioGroup>
          <Input
            type="number"
            placeholder="Proposed Rental Price (ETH)"
            value={rentalPrice}
            onChange={(e) => setRentalPrice(e.target.value)}
          />
          <Button onClick={handleSubmitProposal} disabled={isSubmitting}>
            {isSubmitting ? "Submitting..." : "Submit Proposal"}
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Vote on Proposals</h3>
          <RadioGroup value={selectedProposal} onValueChange={setSelectedProposal}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="proposal1" id="proposal1" />
              <Label htmlFor="proposal1">Proposal 1</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="proposal2" id="proposal2" />
              <Label htmlFor="proposal2">Proposal 2</Label>
            </div>
          </RadioGroup>
          <Button onClick={handleVote} disabled={isVoting}>
            {isVoting ? "Voting..." : "Vote"}
          </Button>
        </div>

        <div>
          <h4 className="text-sm font-medium mb-2">Consensus Progress</h4>
          <Progress value={consensusProgress} className="w-full" />
          <p className="text-sm text-muted-foreground mt-1">{consensusProgress}% agreement reached</p>
        </div>
      </CardContent>
    </Card>
  )
}

