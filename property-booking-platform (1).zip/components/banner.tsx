import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function Banner() {
  return (
    <Alert variant="default" className="rounded-none border-b">
      <AlertCircle className="h-4 w-4" />
      <AlertDescription>
        This is a demo platform. Do not use real funds. All investments are simulated.
      </AlertDescription>
    </Alert>
  )
}

