import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5 z-0" />
      <div
        className="absolute inset-0 z-0 bg-cover bg-center opacity-30"
        style={{ backgroundImage: "url('/placeholder.svg?height=800&width=1600')" }}
      />
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-2xl space-y-6">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            Invest in Properties.
            <br />
            Book Stays.
            <br />
            All Decentralized.
          </h1>
          <p className="text-lg text-muted-foreground md:text-xl">
            Join our platform to invest in real estate using USDT and book stays at properties around the world.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg">
              <Link href="/invest">Start Investing</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/book">Book a Stay</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

