"use client"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { SCROLL_SEPOLIA_CONFIG } from "@/lib/contract-config"

interface NetworkAlertProps {
  isCorrectNetwork: boolean
  switchNetwork: () => Promise<void>
}

export function NetworkAlert({ isCorrectNetwork, switchNetwork }: NetworkAlertProps) {
  if (isCorrectNetwork) return null

  return (
    <Alert className="mb-6" variant="destructive">
      <AlertTitle>Wrong Network</AlertTitle>
      <AlertDescription>
        <p>
          You are not connected to the Scroll Sepolia testnet. Please switch networks to interact with the contract.
        </p>
        <p className="mt-1 text-sm">
          Network: {SCROLL_SEPOLIA_CONFIG.chainName} (Chain ID: {Number.parseInt(SCROLL_SEPOLIA_CONFIG.chainId, 16)})
        </p>
        <div className="mt-2">
          <button onClick={switchNetwork} className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90">
            Switch to Scroll Sepolia
          </button>
        </div>
      </AlertDescription>
    </Alert>
  )
}

