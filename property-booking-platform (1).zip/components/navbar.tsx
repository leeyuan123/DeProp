"use client"

import Link from "next/link"
import { Building, Menu, User, Wallet, X, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/context/web3-context"
import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function Navbar() {
  const {
    address,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet,
    balance,
    isCorrectNetwork,
    switchNetwork,
  } = useWeb3()
  const [isOpen, setIsOpen] = useState(false)

  const shortenAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  const handleConnectOrSwitch = async () => {
    if (isConnected && !isCorrectNetwork) {
      await switchNetwork()
    } else {
      await connectWallet()
    }
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background">
      <div className="container flex flex-col h-auto items-center justify-between">
        <div className="flex w-full h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Building className="h-6 w-6" />
            <span className="text-xl font-bold">DeProp</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:underline">
              Home
            </Link>
            <Link href="/properties" className="text-sm font-medium hover:underline">
              Properties
            </Link>
            <Link href="/invest" className="text-sm font-medium hover:underline">
              Invest
            </Link>
            <Link href="/book" className="text-sm font-medium hover:underline">
              Book a Stay
            </Link>
            <Link href="/dashboard" className="text-sm font-medium hover:underline">
              Dashboard
            </Link>
            <a
              href="https://nomapia.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium hover:underline"
            >
              Nomapia
            </a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            {isConnected && isCorrectNetwork ? (
              <>
                <div className="flex items-center space-x-2 rounded-full bg-secondary px-3 py-1.5">
                  <Wallet className="h-4 w-4" />
                  <span className="text-sm font-medium">{balance} ETH</span>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full">
                      <Avatar>
                        <AvatarFallback>{address ? address[0] : "U"}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>{address ? shortenAddress(address) : ""}</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">Dashboard</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={disconnectWallet}>Disconnect</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button onClick={handleConnectOrSwitch} disabled={isConnecting}>
                {isConnecting ? "Connecting..." : isConnected ? "Switch Network" : "Connect Wallet"}
              </Button>
            )}
          </div>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between border-b py-4">
                  <Link href="/" className="flex items-center space-x-2" onClick={() => setIsOpen(false)}>
                    <Building className="h-6 w-6" />
                    <span className="text-xl font-bold">DeProp</span>
                  </Link>
                  <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                    <X className="h-6 w-6" />
                  </Button>
                </div>

                <nav className="flex flex-col space-y-4 py-6">
                  <Link href="/" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                    Home
                  </Link>
                  <Link href="/properties" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                    Properties
                  </Link>
                  <Link href="/invest" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                    Invest
                  </Link>
                  <Link href="/book" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                    Book a Stay
                  </Link>
                  <Link href="/dashboard" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                    Dashboard
                  </Link>
                </nav>

                <div className="mt-auto border-t py-6">
                  {isConnected ? (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2 rounded-full bg-secondary px-3 py-2">
                        <Wallet className="h-4 w-4" />
                        <span className="text-sm font-medium">{balance} ETH</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{address ? address[0] : "U"}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm">{address ? shortenAddress(address) : ""}</span>
                      </div>
                      <Link
                        href="/dashboard"
                        className="flex items-center space-x-2 text-lg font-medium"
                        onClick={() => setIsOpen(false)}
                      >
                        <User className="h-5 w-5" />
                        <span>Dashboard</span>
                      </Link>
                      <Button
                        onClick={() => {
                          disconnectWallet()
                          setIsOpen(false)
                        }}
                        className="w-full"
                      >
                        Disconnect
                      </Button>
                    </div>
                  ) : (
                    <Button
                      onClick={() => {
                        connectWallet()
                        setIsOpen(false)
                      }}
                      className="w-full"
                      disabled={isConnecting}
                    >
                      {isConnecting ? "Connecting..." : "Connect Wallet"}
                    </Button>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {isConnected && !isCorrectNetwork && (
          <Alert variant="destructive" className="mt-2 mb-2 w-full">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Wrong Network</AlertTitle>
            <AlertDescription>
              Please switch to the Scroll Sepolia network in your wallet to use this app.
              <Button onClick={switchNetwork} variant="outline" size="sm" className="mt-2">
                Switch Network
              </Button>
            </AlertDescription>
          </Alert>
        )}
      </div>
    </header>
  )
}

