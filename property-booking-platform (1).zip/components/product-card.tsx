import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import type { Product } from "@/types/product"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl">
      <CardHeader className="p-0">
        <div className="relative h-64 w-full">
          <Image
            src={product.image || "/placeholder.svg?height=400&width=600"}
            alt={product.name}
            fill
            className="object-cover"
          />
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <CardTitle className="text-2xl mb-2">{product.name}</CardTitle>
        <p className="text-muted-foreground mb-4">{product.description}</p>
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-muted-foreground">Price</p>
            <p className="text-xl font-semibold">{product.price} ETH</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Inventory</p>
            <p className="text-lg">{product.inventory} units</p>
          </div>
        </div>
        <p className="mt-2 text-sm font-medium text-green-600">{product.stock}</p>
      </CardContent>
      <CardFooter className="bg-secondary p-6">
        <Button asChild variant="default" className="w-full">
          <Link href={`/invest?productId=${product.id}`}>Invest Now</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

