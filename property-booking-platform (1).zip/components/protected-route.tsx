"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import { useWeb3 } from "@/context/web3-context"
import { Button } from "@/components/ui/button"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isConnected, connectWallet, isConnecting } = useWeb3()
  const router = useRouter()

  if (!isConnected) {
    return (
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-destructive text-destructive-foreground">
        <div className="container flex items-center justify-between">
          <div>
            <h3 className="font-semibold">Authentication Required</h3>
            <p>Please connect your wallet to continue.</p>
          </div>
          <Button onClick={connectWallet} disabled={isConnecting} variant="secondary">
            {isConnecting ? "Connecting..." : "Connect Wallet"}
          </Button>
        </div>
      </div>
    )
  }

  return <>{children}</>
}

