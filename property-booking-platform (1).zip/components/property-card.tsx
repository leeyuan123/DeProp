import Image from "next/image"
import Link from "next/link"
import { MapPin } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Property } from "@/types/property"
import { Progress } from "@/components/ui/progress"

interface PropertyCardProps {
  property: Property
}

export function PropertyCard({ property }: PropertyCardProps) {
  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100

  return (
    <Card className="overflow-hidden">
      <div className="relative h-48">
        <Image src={property.image || "/placeholder.svg"} alt={property.name} fill className="object-cover" />
        <div className="absolute top-2 right-2">
          <Badge>{property.type}</Badge>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="space-y-1">
            <h3 className="font-semibold text-lg line-clamp-1">{property.name}</h3>
            <div className="flex items-center text-muted-foreground text-sm">
              <MapPin className="h-3.5 w-3.5 mr-1" />
              <span className="line-clamp-1">{property.location}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Expected ROI</p>
              <p className="font-medium">{property.expectedRoi}%</p>
            </div>
            <div>
              <p className="text-muted-foreground">Price per night</p>
              <p className="font-medium">{property.pricePerNight} ETH</p>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Funding</span>
              <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
            </div>
            <Progress value={fundingPercentage} className="h-2" />
            <div className="flex items-center justify-between text-sm">
              <span>{property.fundingCurrent.toLocaleString()} ETH</span>
              <span>{property.fundingGoal.toLocaleString()} ETH</span>
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex gap-2">
        <Button asChild variant="cta" className="w-full">
          <Link href={`/invest?propertyId=${property.id}`}>Invest</Link>
        </Button>
        <Button asChild variant="outline" className="w-full">
          <Link href={`/book?propertyId=${property.id}`}>Book</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

