"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Minus } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface InvestmentActionsProps {
  orderId: string
  status: string
  onConfirm: (orderId: string) => Promise<void>
  onUpdate: (orderId: string, action: "increase" | "decrease", amount: number) => Promise<void>
  onWithdraw: (orderId: string) => Promise<void>
}

export function InvestmentActions({ orderId, status, onConfirm, onUpdate, onWithdraw }: InvestmentActionsProps) {
  const [amount, setAmount] = useState(0.1)
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  const handleConfirm = async () => {
    setIsProcessing(true)
    try {
      await onConfirm(orderId)
    } catch (error) {
      console.error("Failed to confirm investment:", error)
      toast({
        title: "Error",
        description: "Failed to confirm investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleUpdate = async (action: "increase" | "decrease") => {
    setIsProcessing(true)
    try {
      await onUpdate(orderId, action, amount)
    } catch (error) {
      console.error("Failed to update investment:", error)
      toast({
        title: "Error",
        description: "Failed to update investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleWithdraw = async () => {
    setIsProcessing(true)
    try {
      await onWithdraw(orderId)
    } catch (error) {
      console.error("Failed to withdraw investment:", error)
      toast({
        title: "Error",
        description: "Failed to withdraw investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="flex flex-col space-y-2">
      {status === "Pending" && (
        <Button onClick={handleConfirm} disabled={isProcessing}>
          {isProcessing ? "Processing..." : "Confirm Investment"}
        </Button>
      )}
      <div className="flex items-center space-x-2">
        <Button size="icon" onClick={() => handleUpdate("decrease")} disabled={isProcessing}>
          <Minus className="h-4 w-4" />
        </Button>
        <Input
          type="number"
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value))}
          className="w-20"
          disabled={isProcessing}
        />
        <Button size="icon" onClick={() => handleUpdate("increase")} disabled={isProcessing}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button variant="destructive" disabled={isProcessing}>
            Withdraw
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Withdrawal</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to withdraw your investment? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleWithdraw} disabled={isProcessing}>
              {isProcessing ? "Processing..." : "Confirm Withdrawal"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

