import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface SharedWalletInfoProps {
  orderId: string
  projectName: string
  sharedWalletBalance: number
  percentageOwnership: number
  estimatedAnnualReturn: number
}

export function SharedWalletInfo({
  orderId,
  projectName,
  sharedWalletBalance,
  percentageOwnership,
  estimatedAnnualReturn,
}: SharedWalletInfoProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{projectName} - Shared Wallet Info</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p>Shared Wallet Balance: {sharedWalletBalance.toFixed(4)} ETH</p>
          <p>Your Ownership: {percentageOwnership.toFixed(2)}%</p>
          <p>Estimated Annual Return: {estimatedAnnualReturn.toFixed(4)} ETH</p>
        </div>
      </CardContent>
    </Card>
  )
}

