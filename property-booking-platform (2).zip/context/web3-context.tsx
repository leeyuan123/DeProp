"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { ethers } from "ethers"
import { useToast } from "@/components/ui/use-toast"
import { CONTRACT_ADDRESS, CONTRACT_ABI, SCROLL_SEPOLIA_CONFIG } from "@/lib/contract-config"
import { createProvider, getSigner } from "@/lib/provider"

interface Web3ContextType {
  address: string | null
  isConnected: boolean
  isConnecting: boolean
  connectWallet: () => Promise<void>
  disconnectWallet: () => void
  ethBalance: string
  contract: ethers.Contract | null
  isMockData: boolean
  isCorrectNetwork: boolean
  switchNetwork: () => Promise<void>
  CONTRACT_ADDRESS: string
  getSigner: (ethereum: any) => Promise<ethers.Signer>
  sendTransactionWithAutoGas: (
    contract: ethers.Contract,
    method: string,
    args: any[],
    value: bigint,
  ) => Promise<ethers.ContractTransactionResponse>
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined)

const LOCAL_STORAGE_KEY = "wallet_address"
const SCROLL_SEPOLIA_CHAIN_ID = SCROLL_SEPOLIA_CONFIG.chainId // Chain ID for Scroll Sepolia testnet in hex

export function Web3Provider({ children }: { children: ReactNode }) {
  const [address, setAddress] = useState<string | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [ethBalance, setEthBalance] = useState("0")
  const [contract, setContract] = useState<ethers.Contract | null>(null)
  const [isMockData, setIsMockData] = useState(false)
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const savedAddress = localStorage.getItem(LOCAL_STORAGE_KEY)
    if (savedAddress) {
      setAddress(savedAddress)
      setIsConnected(true)
      refreshBalance(savedAddress)
    }
  }, [])

  const refreshBalance = async (walletAddress: string) => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const provider = createProvider(window.ethereum)
        const balance = await provider.getBalance(walletAddress)
        setEthBalance(ethers.formatEther(balance))
      } catch (error) {
        console.error("Failed to fetch balance:", error)
      }
    }
  }

  const checkNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const chainId = await window.ethereum.request({ method: "eth_chainId" })
        const isScrollSepolia = chainId === SCROLL_SEPOLIA_CHAIN_ID
        setIsCorrectNetwork(isScrollSepolia)
        return isScrollSepolia
      } catch (error) {
        console.error("Failed to check network:", error)
        return false
      }
    }
    return false
  }

  const switchNetwork = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: SCROLL_SEPOLIA_CHAIN_ID }],
        })
        return true
      } catch (error: any) {
        if (error.code === 4902) {
          try {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [SCROLL_SEPOLIA_CONFIG],
            })
            return true
          } catch (addError) {
            console.error("Failed to add Scroll Sepolia network:", addError)
            return false
          }
        }
        console.error("Failed to switch network:", error)
        return false
      }
    }
    return false
  }

  const connectWallet = async () => {
    if (isConnecting) return
    setIsConnecting(true)

    try {
      if (typeof window.ethereum === "undefined") {
        toast({
          title: "Error",
          description: "Please install MetaMask to use this app.",
          variant: "destructive",
        })
        return
      }

      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })
      const userAddress = accounts[0]

      if (!userAddress) {
        throw new Error("No accounts found. Please check your MetaMask connection.")
      }

      console.log("Connected wallet address:", userAddress)

      setAddress(userAddress)
      setIsConnected(true)
      localStorage.setItem(LOCAL_STORAGE_KEY, userAddress)

      await refreshBalance(userAddress)

      const networkCorrect = await checkNetwork()
      if (!networkCorrect) {
        toast({
          title: "Wrong Network",
          description: "Please switch to the Scroll Sepolia testnet to use this app.",
          variant: "destructive",
        })
        await switchNetwork()
      }

      // Initialize contract after setting the address
      await initializeContract(userAddress)

      toast({
        title: "Success",
        description: "Wallet connected successfully",
      })
    } catch (error) {
      console.error("Failed to connect wallet:", error)
      toast({
        title: "Error",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const initializeContract = async (userAddress: string) => {
    console.log("Initializing contract...")
    console.log("Ethereum provider available:", typeof window.ethereum !== "undefined")
    console.log("User address:", userAddress)
    console.log("Contract address:", CONTRACT_ADDRESS)

    if (typeof window.ethereum === "undefined") {
      console.error("Ethereum provider not available")
      setContract(null)
      setIsMockData(true)
      return null
    }

    if (!userAddress) {
      console.error("User wallet address not available")
      setContract(null)
      setIsMockData(true)
      return null
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum)

      // Remove gas price check
      /*
      const feeData = await provider.getFeeData()
      const currentGasPrice = ethers.formatUnits(feeData.gasPrice || 0n, "gwei")
      console.log("Current gas price:", currentGasPrice, "Gwei")

      if (Number(currentGasPrice) > 0.1) {
        console.warn("Gas price is high:", currentGasPrice, "Gwei")
      }
      */

      const network = await provider.getNetwork()
      console.log("Connected network:", network.chainId)

      if (network.chainId !== BigInt(SCROLL_SEPOLIA_CONFIG.chainId)) {
        console.error("Wrong network. Please switch to Scroll Sepolia.")
        setIsCorrectNetwork(false)
        return null
      }

      setIsCorrectNetwork(true)
      const signer = await provider.getSigner()
      console.log("Signer obtained:", signer.address)

      if (signer.address.toLowerCase() !== userAddress.toLowerCase()) {
        console.error("Signer address does not match connected wallet address")
        throw new Error("Signer address mismatch")
      }

      const contractInstance = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)
      console.log("Contract instance created")

      // Test contract connection
      try {
        const nextOrderId = await contractInstance.nextOrderId()
        console.log("Contract connected successfully. Next order ID:", nextOrderId.toString())
        setContract(contractInstance)
        setIsMockData(false)
        return contractInstance
      } catch (testError) {
        console.error("Contract connection test failed:", testError)
        if (testError instanceof Error) {
          console.error("Error message:", testError.message)
          console.error("Error stack:", testError.stack)
        }
        throw new Error("Failed to connect to the contract. Please check the contract address and ABI.")
      }
    } catch (error) {
      console.error("Failed to initialize contract:", error)
      if (error instanceof Error) {
        console.error("Error message:", error.message)
        console.error("Error stack:", error.stack)
      }
      setContract(null)
      setIsMockData(true)
      throw error
    }
  }

  // Add this function to the Web3Provider component
  const sendTransactionWithAutoGas = async (contract: ethers.Contract, method: string, args: any[], value: bigint) => {
    const provider = new ethers.BrowserProvider(window.ethereum)
    const signer = await provider.getSigner()

    // Get the current gas price and increase it by 20%
    const feeData = await provider.getFeeData()
    const gasPrice = feeData.gasPrice ? (feeData.gasPrice * BigInt(120)) / BigInt(100) : undefined

    // Estimate gas limit
    const estimatedGas = await contract.estimateGas[method](...args, { value })
    const gasLimit = (estimatedGas * BigInt(120)) / BigInt(100) // Add 20% buffer

    // Send the transaction
    const tx = await contract.connect(signer)[method](...args, {
      value,
      gasLimit,
      gasPrice,
    })

    return tx
  }

  const disconnectWallet = () => {
    setAddress(null)
    setIsConnected(false)
    setEthBalance("0")
    setContract(null)
    localStorage.removeItem(LOCAL_STORAGE_KEY)
    toast({ title: "Success", description: "Wallet disconnected" })
  }

  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      window.ethereum.on("accountsChanged", (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet()
        } else {
          setAddress(accounts[0])
          localStorage.setItem(LOCAL_STORAGE_KEY, accounts[0])
          refreshBalance(accounts[0])
          initializeContract(accounts[0])
        }
      })

      window.ethereum.on("chainChanged", () => {
        checkNetwork()
        initializeContract(address || "")
      })
    }

    return () => {
      if (typeof window.ethereum !== "undefined") {
        window.ethereum.removeAllListeners()
      }
    }
  }, [address])

  useEffect(() => {
    if (address) {
      initializeContract(address)
      checkNetwork()
    }
  }, [address])

  const contextValue: Web3ContextType = {
    address,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet,
    ethBalance,
    contract,
    isMockData,
    isCorrectNetwork,
    switchNetwork,
    CONTRACT_ADDRESS,
    getSigner,
    sendTransactionWithAutoGas,
  }

  return <Web3Context.Provider value={contextValue}>{children}</Web3Context.Provider>
}

export function useWeb3() {
  const context = useContext(Web3Context)
  if (context === undefined) {
    throw new Error("useWeb3 must be used within a Web3Provider")
  }
  return context
}

