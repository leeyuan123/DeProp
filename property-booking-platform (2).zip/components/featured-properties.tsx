import Link from "next/link"
import { PropertyCard } from "@/components/property-card"
import { properties } from "@/data/properties"

export function FeaturedProperties() {
  // Only show the first 3 properties on the homepage
  const featuredProperties = properties.slice(0, 3)

  return (
    <section className="container">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Featured Properties</h2>
          <p className="text-muted-foreground mt-2">Discover our top investment opportunities</p>
        </div>
        <Link href="/properties" className="text-primary underline underline-offset-4">
          View all properties
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {featuredProperties.map((property) => (
          <PropertyCard key={property.id} property={property} />
        ))}
      </div>
    </section>
  )
}

