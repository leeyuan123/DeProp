import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Image from "next/image"

interface SharedWalletInfoProps {
  orderId: string
  projectName: string
  projectImage?: string
  sharedWalletBalance: number
  percentageOwnership: number
  estimatedAnnualReturn: number
  totalFundingGoal: number
}

export function SharedWalletInfo({
  orderId,
  projectName,
  projectImage,
  sharedWalletBalance,
  percentageOwnership,
  estimatedAnnualReturn,
  totalFundingGoal,
}: SharedWalletInfoProps) {
  // Calculate funding percentage
  const fundingPercentage = (sharedWalletBalance / totalFundingGoal) * 100

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-4">
        {projectImage && (
          <div className="relative h-16 w-16 overflow-hidden rounded-md">
            <Image
              src={projectImage || "/placeholder.svg?height=64&width=64"}
              alt={projectName}
              fill
              className="object-cover"
            />
          </div>
        )}
        <CardTitle>{projectName}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Funding Progress</span>
              <span className="font-medium">{fundingPercentage.toFixed(1)}%</span>
            </div>
            <Progress value={fundingPercentage} className="h-2" />
            <div className="flex justify-between text-sm">
              <span>{sharedWalletBalance.toFixed(4)} ETH raised</span>
              <span>{totalFundingGoal.toFixed(2)} ETH goal</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Shared Wallet Balance</p>
              <p className="font-medium">{sharedWalletBalance.toFixed(4)} ETH</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Your Ownership</p>
              <p className="font-medium">{percentageOwnership.toFixed(2)}%</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Estimated Annual Return</p>
              <p className="font-medium">{estimatedAnnualReturn.toFixed(4)} ETH</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

