"use client"

import Link from "next/link"
import { Building, Menu, User, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/context/web3-context"
import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Navbar() {
  const { address, isConnected, isConnecting, connectWallet, disconnectWallet, ethBalance } = useWeb3()
  const [isOpen, setIsOpen] = useState(false)

  const shortenAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background">
      <div className="container flex flex-col h-auto items-center justify-between">
        <div className="flex w-full h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Building className="h-6 w-6" />
            <span className="text-xl font-bold">DeProp</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:underline">
              Home
            </Link>
            <Link href="/properties" className="text-sm font-medium hover:underline">
              Properties
            </Link>
            <Link href="/invest" className="text-sm font-medium hover:underline">
              Invest
            </Link>
            <Link href="/book" className="text-sm font-medium hover:underline">
              Book a Stay
            </Link>
            <Link href="/dashboard" className="text-sm font-medium hover:underline">
              Dashboard
            </Link>
            <Link href="/order" className="text-sm font-medium hover:underline">
              Order
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            {isConnected ? (
              <>
                <div className="flex items-center space-x-2 rounded-full bg-secondary px-3 py-1.5">
                  <Wallet className="h-4 w-4" />
                  <span className="text-sm font-medium">{Number(ethBalance).toFixed(4)} ETH</span>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full">
                      <Avatar>
                        <AvatarFallback>{address ? address[0] : "U"}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>{address ? shortenAddress(address) : ""}</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">Dashboard</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/order">Order</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={disconnectWallet}>Disconnect</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button onClick={connectWallet} disabled={isConnecting}>
                {isConnecting ? "Connecting..." : "Connect Wallet"}
              </Button>
            )}
          </div>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col space-y-4">
                <Link href="/" className="text-sm font-medium hover:underline">
                  Home
                </Link>
                <Link href="/properties" className="text-sm font-medium hover:underline">
                  Properties
                </Link>
                <Link href="/invest" className="text-sm font-medium hover:underline">
                  Invest
                </Link>
                <Link href="/book" className="text-sm font-medium hover:underline">
                  Book a Stay
                </Link>
                <Link href="/dashboard" className="text-sm font-medium hover:underline">
                  Dashboard
                </Link>
                <Link href="/order" className="text-sm font-medium hover:underline">
                  Order
                </Link>
                {isConnected ? (
                  <>
                    <div className="flex items-center space-x-2 rounded-full bg-secondary px-3 py-1.5">
                      <Wallet className="h-4 w-4" />
                      <span className="text-sm font-medium">{Number(ethBalance).toFixed(4)} ETH</span>
                    </div>
                    <Button onClick={disconnectWallet}>Disconnect</Button>
                  </>
                ) : (
                  <Button onClick={connectWallet} disabled={isConnecting}>
                    {isConnecting ? "Connecting..." : "Connect Wallet"}
                  </Button>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

