import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ShoppingBag, ArrowRight } from "lucide-react"
import Link from "next/link"

interface EmptyOrdersStateProps {
  isMockData?: boolean
}

export function EmptyOrdersState({ isMockData = false }: EmptyOrdersStateProps) {
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <ShoppingBag className="h-6 w-6 text-primary" />
        </div>
        <CardTitle>No Orders Found</CardTitle>
        <CardDescription>
          {isMockData
            ? "You're viewing mock data. In a real environment, your orders would appear here."
            : "You haven't placed any investment orders yet on this blockchain."}
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center text-muted-foreground">
        <p>Start by browsing our available properties and make your first investment.</p>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <Button asChild className="w-full">
          <Link href="/properties" className="flex items-center justify-center">
            Browse Properties <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
        <Button variant="outline" asChild className="w-full">
          <Link href="/invest/1" className="flex items-center justify-center">
            Invest in Diamond Cabin
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

