import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { Product } from "@/types/product"

interface ProductCardProps {
  product: Product
  comingSoon?: boolean
}

export function ProductCard({ product, comingSoon = false }: ProductCardProps) {
  const fundingPercentage = (product.fundingCurrent / product.fundingGoal) * 100

  return (
    <Card className={`overflow-hidden transition-shadow duration-300 ${comingSoon ? "opacity-75" : "hover:shadow-lg"}`}>
      <div className="relative h-48">
        <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
        <div className="absolute top-2 right-2 flex gap-2">
          <Badge>{product.type}</Badge>
          {comingSoon && (
            <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
              Coming Soon
            </Badge>
          )}
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="space-y-1">
            <h3 className="font-semibold text-lg line-clamp-1">{product.name}</h3>
            <div className="text-muted-foreground text-sm line-clamp-1">{product.location}</div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Expected ROI</p>
              <p className="font-medium">{product.expectedRoi}%</p>
            </div>
            <div>
              <p className="text-muted-foreground">Price</p>
              <p className="font-medium">{product.fundingGoal} ETH</p>
            </div>
          </div>

          {!comingSoon && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Funding</span>
                <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
              </div>
              <Progress value={fundingPercentage} className="h-2" />
              <div className="flex items-center justify-between text-sm">
                <span>{product.fundingCurrent.toLocaleString()} ETH</span>
                <span>{product.fundingGoal.toLocaleString()} ETH</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

