"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Minus, ArrowUpRight } from "lucide-react"

interface InvestmentActionsProps {
  orderId: string
  currentAmount: number
  onIncrease: (orderId: string, amount: number) => Promise<void>
  onDecrease: (orderId: string, amount: number) => Promise<void>
  onWithdraw: (orderId: string) => Promise<void>
  isProcessing?: boolean
  minAmount?: number
  maxAmount?: number
}

export function InvestmentActions({
  orderId,
  currentAmount,
  onIncrease,
  onDecrease,
  onWithdraw,
  isProcessing = false,
  minAmount = 0.0001,
  maxAmount = 1.0,
}: InvestmentActionsProps) {
  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center gap-4">
          <Input type="number" value={currentAmount} readOnly className="w-32" disabled={isProcessing} />
          <span className="text-sm font-medium">ETH</span>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => onDecrease(orderId, 0.0001)}
            disabled={isProcessing || currentAmount <= minAmount}
            variant="outline"
            className="flex-1"
          >
            <Minus className="h-4 w-4 mr-2" />
            Decrease
          </Button>
          <Button
            onClick={() => onIncrease(orderId, 0.0001)}
            disabled={isProcessing || currentAmount >= maxAmount}
            variant="outline"
            className="flex-1"
          >
            <Plus className="h-4 w-4 mr-2" />
            Increase
          </Button>
        </div>

        <Button onClick={() => onWithdraw(orderId)} disabled={isProcessing} variant="destructive" className="w-full">
          <ArrowUpRight className="h-4 w-4 mr-2" />
          Withdraw Investment
        </Button>

        <div className="text-sm text-muted-foreground text-center">Current Investment: {currentAmount} ETH</div>
      </CardContent>
    </Card>
  )
}

