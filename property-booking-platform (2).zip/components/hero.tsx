import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5 z-0" />
      <div
        className="absolute inset-0 z-0 bg-cover bg-center opacity-30"
        style={{ backgroundImage: "url('/placeholder.svg?height=800&width=1600')" }}
      />
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-2xl space-y-6">
          <h1 className="text-5xl font-bold mb-6 leading-tight tracking-tight">
            The Future of Product
            <br />
            Investment
          </h1>
          <p className="text-xl mb-12 text-gray-200 font-light">
            Experience luxury living and smart investing with our curated collection of premium products
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              asChild
              size="lg"
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-6 h-auto text-base font-medium rounded-lg transition-colors"
            >
              <Link href="/invest">Start Investing</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="bg-transparent hover:bg-white/10 text-white px-8 py-6 h-auto text-base font-medium border-2 border-white/80 rounded-lg transition-colors"
            >
              <Link href="/book">Book a Stay</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

