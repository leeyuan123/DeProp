"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { MapPin, Calendar, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"

export default function BookPage() {
  const router = useRouter()
  const { isConnected } = useWeb3()
  const { toast } = useToast()
  const [selectedProperty, setSelectedProperty] = useState<string | null>(null)

  const handleSelectProperty = (propertyId: string) => {
    setSelectedProperty(propertyId)
  }

  const handleProceedToBooking = () => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to book a stay.",
        variant: "destructive",
      })
      return
    }

    if (!selectedProperty) {
      toast({
        title: "No property selected",
        description: "Please select a property to book.",
        variant: "destructive",
      })
      return
    }

    router.push(`/book/${selectedProperty}`)
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Book a Stay</h1>
      <p className="text-xl text-muted-foreground mb-8">Choose a property to book your stay:</p>

      <div className="grid md:grid-cols-2 gap-6">
        {properties.map((property) => (
          <Card
            key={property.id}
            className={`cursor-pointer transition-all ${selectedProperty === property.id ? "ring-2 ring-primary" : ""}`}
            onClick={() => handleSelectProperty(property.id)}
          >
            <CardHeader className="p-0">
              <div className="relative h-48 w-full">
                <Image
                  src={property.image || "/placeholder.svg"}
                  alt={property.name}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <CardTitle className="text-xl mb-2">{property.name}</CardTitle>
              <div className="flex items-center text-muted-foreground mb-2">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{property.location}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">{property.description}</p>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>{property.pricePerNight} ETH / night</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  <span>Max {property.capacity} guests</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant={selectedProperty === property.id ? "default" : "outline"}>
                {selectedProperty === property.id ? "Selected" : "Select Property"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <Button size="lg" onClick={handleProceedToBooking} disabled={!selectedProperty}>
          Proceed to Booking
        </Button>
      </div>
    </div>
  )
}

