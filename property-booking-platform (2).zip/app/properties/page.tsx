"use client"

import Link from "next/link"
import { ProductCard } from "@/components/product-card"
import { products } from "@/data/products"

export default function ProductsPage() {
  return (
    <div className="container py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">All Products</h1>
        <p className="text-muted-foreground mt-2">Browse our curated list of investment opportunities</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) =>
          !product.isComingSoon ? (
            <Link key={product.id} href={`/invest/${product.id}`}>
              <ProductCard product={product} />
            </Link>
          ) : (
            <div key={product.id}>
              <ProductCard product={product} comingSoon />
            </div>
          ),
        )}
      </div>
    </div>
  )
}

