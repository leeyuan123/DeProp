"use client"

import { useState, useCallback, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function InvestPage() {
  const router = useRouter()
  const { isConnected, address, ethBalance, connectWallet } = useWeb3()
  const { toast } = useToast()
  const [amount, setAmount] = useState(0.0001) // Start with minimum investment amount
  const [isProcessing, setIsProcessing] = useState(false)
  const property = properties[0] // For demo, using the first property

  // Add useEffect to check wallet connection status
  useEffect(() => {
    if (isConnected && address) {
      // Update UI when wallet is connected
      console.log("Wallet connected:", address)
    }
  }, [isConnected, address])

  const handleSendOrder = async () => {
    if (!isConnected || !address) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to invest.",
        variant: "destructive",
      })
      return
    }

    router.push(`/invest/order-confirm?amount=${amount}&propertyId=${property.id}`)
  }

  const handleInvest = useCallback(async () => {
    if (!isConnected || !address) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to invest.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsProcessing(true)

      // Here you would typically call your smart contract
      // For demo, we'll just simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Investment Successful",
        description: `Successfully invested ${amount} ETH in ${property.name}`,
      })

      router.push("/dashboard")
    } catch (error) {
      console.error("Investment failed:", error)
      toast({
        title: "Investment Failed",
        description: "There was an error processing your investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }, [isConnected, address, amount, property.name, router, toast])

  const handleSliderChange = useCallback((value: number[]) => {
    // Round to 4 decimal places to avoid floating point precision issues
    setAmount(Number(value[0].toFixed(4)))
  }, [])

  if (!property) {
    return (
      <div className="container py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Property not found.</AlertDescription>
        </Alert>
      </div>
    )
  }

  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100
  const expectedReturn = (amount * property.expectedRoi) / 100
  const ownershipPercentage = (amount / property.fundingGoal) * 100

  const minInvestment = 0.0001 // Minimum investment amount in ETH
  const maxInvestment = 1 // Maximum investment amount in ETH (total property price)

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-2">Invest in {property.name}</h1>
      <p className="text-muted-foreground mb-6">Complete your investment in this unique product</p>

      <div className="grid gap-6">
        <Card>
          <CardHeader className="p-0">
            <div className="relative h-64 w-full">
              <Image
                src={property.image || "/placeholder.svg"}
                alt={property.name}
                fill
                className="object-cover rounded-t-lg"
              />
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold">{property.name}</h2>
            <div className="flex items-center text-muted-foreground mt-1">
              <span>{property.stock}</span>
            </div>
            <p className="mt-4">{property.description}</p>

            <div className="mt-6 space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Inventory</span>
                  <span>{property.inventory} units</span>
                </div>
                <Progress value={fundingPercentage} className="h-2" />
                <div className="flex justify-between text-sm mt-1">
                  <span>{property.fundingCurrent.toLocaleString()} ETH raised</span>
                  <span>{property.fundingGoal.toLocaleString()} ETH goal</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Investment Details</CardTitle>
            <CardDescription>
              {isConnected && ethBalance
                ? `Your current balance: ${Number(ethBalance).toFixed(4)} ETH`
                : "Please connect your wallet to invest"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium">Investment Amount (ETH)</label>
                <div className="mt-2">
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(Number(Number.parseFloat(e.target.value).toFixed(4)))}
                    min={0.0001}
                    max={1}
                    step={0.0001}
                    disabled={!isConnected || isProcessing}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="rounded-lg bg-muted p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Expected Annual Return</span>
                    <span>{((amount * property.expectedRoi) / 100).toFixed(4)} ETH</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Ownership Percentage</span>
                    <span>{((amount / 1) * 100).toFixed(2)}%</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" asChild>
              <Link href="/properties">Cancel</Link>
            </Button>
            {!isConnected ? (
              <Button onClick={connectWallet}>Connect Wallet</Button>
            ) : (
              <Button onClick={handleSendOrder} disabled={isProcessing || amount < 0.0001}>
                {isProcessing ? "Processing..." : "Send Order"}
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

