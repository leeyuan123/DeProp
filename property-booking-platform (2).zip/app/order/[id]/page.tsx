"use client"

import { useParams } from "next/navigation"
import { ProtectedRoute } from "@/components/protected-route"

export default function OrderDetailsPage() {
  const params = useParams()
  const { id } = params

  return (
    <ProtectedRoute>
      <div className="container py-10">
        <h1 className="text-3xl font-bold mb-6">Order Details: {id}</h1>
        <p>This page will show detailed information about the order.</p>
      </div>
    </ProtectedRoute>
  )
}

