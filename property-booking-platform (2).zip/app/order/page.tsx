"use client"

import { useState, useEffect } from "react"
import { useWeb3 } from "@/context/web3-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { ethers } from "ethers"
import { useToast } from "@/components/ui/use-toast"
import { EmptyOrdersState } from "@/components/empty-orders-state"
import Image from "next/image"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

enum OrderStatus {
  Pending = 0,
  Confirmed = 1,
  Cancelled = 2,
}

interface Order {
  orderId: number
  projectId: number
  amount: string
  amountInWei: bigint
  buyer: string
  seller: string
  status: OrderStatus
  selected?: boolean
}

const TOTAL_THRESHOLD = 1 // ETH
const PROJECT_NAME = "Diamond Cabin"
const PROJECT_IMAGE =
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/f11ce9b8-8e81-4388-a9ee-9a1b624baefd.jpg-px8MUsvjHAogrFlvezRQJHmLSpBMAP.jpeg"

export default function OrderPage() {
  const { address, contract, isConnected } = useWeb3()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const [totalRaised, setTotalRaised] = useState(0)
  const [contractBalance, setContractBalance] = useState("0")
  const { toast } = useToast()

  // Calculate total investment and percentage
  const totalInvestment = orders.reduce((sum, order) => sum + Number(order.amount), 0)
  const totalPercentageOwn = (totalInvestment / TOTAL_THRESHOLD) * 100

  useEffect(() => {
    if (isConnected && contract) {
      fetchOrders()
      fetchContractBalance()
    }
  }, [isConnected, contract, address])

  const fetchContractBalance = async () => {
    try {
      const provider = new ethers.BrowserProvider(window.ethereum)
      const balance = await provider.getBalance(contract.target)
      setContractBalance(ethers.formatEther(balance))
    } catch (error) {
      console.error("Error fetching contract balance:", error)
    }
  }

  const fetchOrders = async () => {
    setIsLoading(true)
    try {
      const nextOrderId = await contract.nextOrderId()
      const fetchedOrders = []
      let raised = 0

      for (let i = 0; i < nextOrderId; i++) {
        try {
          const order = await contract.orders(i)
          if (
            order.buyer.toLowerCase() === address?.toLowerCase() &&
            order.amount > BigInt(0) &&
            order.status !== OrderStatus.Cancelled
          ) {
            const amountInWei = order.amount
            const amountInEth = Number(ethers.formatEther(amountInWei))
            raised += amountInEth
            fetchedOrders.push({
              orderId: i,
              projectId: Number(order.projectId),
              amount: amountInEth.toString(),
              amountInWei: amountInWei,
              buyer: order.buyer,
              seller: order.seller,
              status: Number(order.status),
              selected: false,
            })
          }
        } catch (orderError) {
          console.error(`Error fetching order ${i}:`, orderError)
        }
      }

      setOrders(fetchedOrders)
      setTotalRaised(raised)
    } catch (error) {
      console.error("Error fetching orders:", error)
      toast({
        title: "Error",
        description: "Failed to fetch orders. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const withdrawInvestment = async (orderId: number) => {
    setIsProcessing(true)
    try {
      const tx = await contract.withdrawInvestment(orderId)
      await tx.wait()
      toast({
        title: "Success",
        description: "Investment withdrawn successfully!",
      })
      fetchOrders()
    } catch (error) {
      console.error("Error withdrawing investment:", error)
      toast({
        title: "Error",
        description: "Failed to withdraw investment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const batchWithdrawInvestments = async () => {
    setIsProcessing(true)
    try {
      const selectedOrderIds = orders.filter((order) => order.selected).map((order) => order.orderId)

      for (const orderId of selectedOrderIds) {
        const tx = await contract.withdrawInvestment(orderId)
        await tx.wait()
      }

      toast({
        title: "Success",
        description: "Selected investments withdrawn successfully!",
      })
      fetchOrders()
    } catch (error) {
      console.error("Error batch withdrawing investments:", error)
      toast({
        title: "Error",
        description: "Failed to withdraw selected investments. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const toggleOrderSelection = (orderId: number) => {
    setOrders(orders.map((order) => (order.orderId === orderId ? { ...order, selected: !order.selected } : order)))
  }

  const getStatusText = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.Pending:
        return "Pending"
      case OrderStatus.Confirmed:
        return "Confirmed"
      case OrderStatus.Cancelled:
        return "Cancelled"
      default:
        return "Unknown"
    }
  }

  if (isLoading) {
    return <div>Loading orders...</div>
  }

  if (orders.length === 0) {
    return <EmptyOrdersState />
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Your Orders</h1>

      {/* Project Overview Card */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Project Overview: {PROJECT_NAME}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <Image
              src={PROJECT_IMAGE || "/placeholder.svg"}
              alt={PROJECT_NAME}
              width={100}
              height={100}
              className="rounded-lg"
            />
            <div>
              <p className="font-semibold">Product Type: {PROJECT_NAME}</p>
              <p>Project ID: 1 (Diamond Cabin Pool)</p>
              <p className="mt-2 font-medium">
                Your Total Investment: {totalInvestment.toFixed(4)} ETH ({totalPercentageOwn.toFixed(4)}%)
              </p>
            </div>
          </div>
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <p className="font-semibold">Pool Contract Balance: {contractBalance} ETH</p>
              <p className="text-sm text-muted-foreground">Target: {TOTAL_THRESHOLD} ETH</p>
            </div>
            <Progress value={(Number(contractBalance) / TOTAL_THRESHOLD) * 100} className="h-2" />
            <div className="flex justify-between text-sm mt-1">
              <span>Current: {contractBalance} ETH</span>
              <span>Progress: {((Number(contractBalance) / TOTAL_THRESHOLD) * 100).toFixed(2)}%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Investment Summary Table */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Your Investment Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order #</TableHead>
                <TableHead>Amount (ETH)</TableHead>
                <TableHead>Individual %</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => {
                const individualPercentage = (Number(order.amount) / TOTAL_THRESHOLD) * 100
                return (
                  <TableRow key={order.orderId}>
                    <TableCell>{order.orderId}</TableCell>
                    <TableCell>{order.amount}</TableCell>
                    <TableCell>{individualPercentage.toFixed(4)}%</TableCell>
                    <TableCell>{getStatusText(order.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id={`table-order-${order.orderId}`}
                          checked={order.selected}
                          onCheckedChange={() => toggleOrderSelection(order.orderId)}
                        />
                        <Button size="sm" onClick={() => withdrawInvestment(order.orderId)} disabled={isProcessing}>
                          Withdraw
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
              <TableRow className="font-medium">
                <TableCell>Total</TableCell>
                <TableCell>{totalInvestment.toFixed(4)} ETH</TableCell>
                <TableCell>{totalPercentageOwn.toFixed(4)}%</TableCell>
                <TableCell colSpan={2}>
                  <Button
                    onClick={batchWithdrawInvestments}
                    disabled={isProcessing || !orders.some((order) => order.selected)}
                  >
                    Withdraw Selected
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

