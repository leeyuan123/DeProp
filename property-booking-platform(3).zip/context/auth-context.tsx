"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useToast } from "@/components/ui/use-toast"

export interface User {
  id: string
  name: string
  email: string
  walletAddress: string
}

interface AuthContextType {
  user: User | null
  login: () => void
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate loading user from localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = () => {
    // Simulate wallet connection and authentication
    setIsLoading(true)

    // Simulate API call delay
    setTimeout(() => {
      const mockUser: User = {
        id: "1",
        name: "John Doe",
        email: "john@example.com",
        walletAddress: "0x" + Math.random().toString(16).slice(2, 12),
      }

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
      setIsLoading(false)

      toast({
        title: "Wallet Connected",
        description: "You have successfully connected your wallet.",
      })
    }, 1000)
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")

    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    })
  }

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

