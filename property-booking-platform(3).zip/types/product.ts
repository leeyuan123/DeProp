export interface Product {
  id: string
  name: string
  description: string
  image?: string
  price: number
  inventory: number
  stock: string
  type: string
  location: string
  fundingGoal: number
  fundingCurrent: number
  expectedRoi: number
  minInvestment: number
  isComingSoon: boolean
}

