export const SCROLL_SEPOLIA_CONFIG = {
  chainId: "0x8274f", // 534351 in hex
  chainName: "Scroll Sepolia",
  nativeCurrency: {
    name: "ETH",
    symbol: "ETH",
    decimals: 18,
  },
  rpcUrls: ["https://sepolia-rpc.scroll.io/"],
  blockExplorerUrls: ["https://sepolia.scrollscan.com/"],
}

