"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import { useWeb3 } from "@/context/web3-context"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isConnected, connectWallet, isConnecting } = useWeb3()
  const router = useRouter()
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  // If not mounted yet (server-side), render children without protection
  if (!isMounted) {
    return <>{children}</>
  }

  // Client-side protection
  if (!isConnected) {
    return (
      <>
        {children}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-destructive text-destructive-foreground">
          <div className="container flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Authentication Required</h3>
              <p>Please connect your wallet to continue.</p>
            </div>
            <Button onClick={connectWallet} disabled={isConnecting} variant="secondary">
              {isConnecting ? "Connecting..." : "Connect Wallet"}
            </Button>
          </div>
        </div>
      </>
    )
  }

  return <>{children}</>
}

