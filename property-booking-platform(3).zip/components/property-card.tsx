import Image from "next/image"
import { MapPin } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Property } from "@/types/property"
import { Progress } from "@/components/ui/progress"

interface PropertyCardProps {
  property: Property
  comingSoon?: boolean
}

export function PropertyCard({ property, comingSoon = false }: PropertyCardProps) {
  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100

  return (
    <Card className={`overflow-hidden transition-shadow duration-300 ${comingSoon ? "opacity-75" : "hover:shadow-lg"}`}>
      <div className="relative h-48">
        <Image src={property.image || "/placeholder.svg"} alt={property.name} fill className="object-cover" />
        <div className="absolute top-2 right-2 flex gap-2">
          <Badge>{property.type}</Badge>
          {comingSoon && (
            <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
              Coming Soon
            </Badge>
          )}
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="space-y-1">
            <h3 className="font-semibold text-lg line-clamp-1">{property.name}</h3>
            <div className="flex items-center text-muted-foreground text-sm">
              <MapPin className="h-3.5 w-3.5 mr-1" />
              <span className="line-clamp-1">{property.location}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Expected ROI</p>
              <p className="font-medium">{property.expectedRoi}%</p>
            </div>
            <div>
              <p className="text-muted-foreground">Price</p>
              <p className="font-medium">{property.fundingGoal} ETH</p>
            </div>
          </div>

          {!comingSoon && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Funding</span>
                <span className="font-medium">{fundingPercentage.toFixed(0)}%</span>
              </div>
              <Progress value={fundingPercentage} className="h-2" />
              <div className="flex items-center justify-between text-sm">
                <span>{property.fundingCurrent.toLocaleString()} ETH</span>
                <span>{property.fundingGoal.toLocaleString()} ETH</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

