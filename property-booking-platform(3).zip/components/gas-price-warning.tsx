import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

interface GasPriceWarningProps {
  gasPrice: string
  maxGasPrice?: string
}

export function GasPriceWarning({ gasPrice, maxGasPrice = "0.1" }: GasPriceWarningProps) {
  const isHighGas = Number(gasPrice) > Number(maxGasPrice)

  if (!isHighGas) return null

  return (
    <Alert variant="warning">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>High Gas Price Warning</AlertTitle>
      <AlertDescription>
        Current gas price is {Number(gasPrice).toFixed(2)} Gwei. You may want to wait for lower gas prices.
        <br />
        <span className="text-sm text-muted-foreground mt-1">
          Tip: Try again when gas prices are below {maxGasPrice} Gwei for better transaction costs.
        </span>
      </AlertDescription>
    </Alert>
  )
}

