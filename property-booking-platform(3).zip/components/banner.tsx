import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

export function Banner() {
  return (
    <Alert variant="default" className="rounded-none border-b">
      <div className="container flex items-center justify-between">
        <div className="flex items-center">
          <AlertCircle className="h-4 w-4 mr-2" />
          <AlertDescription>
            This is a demo platform. Do not use real funds. All investments are simulated.
          </AlertDescription>
        </div>
        <Button asChild variant="link" className="font-semibold text-primary hover:text-primary/80">
          <a href="https://nomapia.com" target="_blank" rel="noopener noreferrer">
            NOMAPIA
          </a>
        </Button>
      </div>
    </Alert>
  )
}

