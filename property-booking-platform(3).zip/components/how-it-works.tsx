import { Building, Calendar, Wallet } from "lucide-react"

export function HowItWorks() {
  return (
    <section className="container">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold tracking-tight">How It Works</h2>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          Our platform makes it easy to invest in properties and book stays using USDT
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Wallet className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Connect Your Wallet</h3>
          <p className="text-muted-foreground">
            Connect your MetaMask wallet to our platform to start investing in properties using USDT.
          </p>
        </div>

        <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Building className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Invest in Properties</h3>
          <p className="text-muted-foreground">
            Browse our curated list of properties and invest in the ones that match your criteria.
          </p>
        </div>

        <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Calendar className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Book Stays</h3>
          <p className="text-muted-foreground">
            Use your USDT to book stays at properties around the world, with special rates for investors.
          </p>
        </div>
      </div>
    </section>
  )
}

