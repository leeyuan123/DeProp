import type React from "react"
import "@/app/globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Web3Provider } from "@/context/web3-context"
import { AuthProvider } from "@/context/auth-context"
import { WalletProvider } from "@/context/wallet-context"
import { Toaster } from "@/components/ui/toaster"
import { Banner } from "@/components/banner"
import { Navbar } from "@/components/navbar"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DeProp - Decentralized Property Booking",
  description: "Invest in properties and book stays using USDT",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Web3Provider>
          <AuthProvider>
            <WalletProvider>
              <Banner />
              <Navbar />
              <main className="pt-16">{children}</main>
              <Toaster />
            </WalletProvider>
          </AuthProvider>
        </Web3Provider>
      </body>
    </html>
  )
}



import './globals.css'