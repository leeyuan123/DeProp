import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Building, Globe, TrendingUp, Users, CheckCircle2, Lightbulb, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-80 w-full">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202024-12-26%2017.21.52%20-%20A%20zoomed-in%20interior%20view%20of%20a%20modular%2C%20adaptive%20living%20space%20in%20a%20futuristic%20coastal%20community%20inspired%20by%20Tomorrowland%20and%20Avatar.%20The%20space%20showcas-coPhL9BgPbJx05RydTjnlps3LAzyIy.jpeg"
          alt="DeProp Vision"
          fill
          className="object-cover brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-transparent opacity-60" />
        <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">About DeProp</h1>
          <p className="text-xl text-white max-w-2xl mb-6">Empowering Your Future Living Spaces</p>
          <a
            href="/pitch-deck"
            className="inline-block bg-primary text-white px-6 py-3 rounded-md font-medium hover:bg-primary/90 transition-colors w-fit text-lg"
          >
            View Pitch Deck
          </a>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-5xl mx-auto space-y-10">
          {/* Overview Section */}
          <Card className="overflow-hidden border-none shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 p-6">
              <div className="flex items-center gap-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <Building className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-3xl font-bold">DeProp: Empowering Your Future Living Spaces</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              <div className="space-y-8">
                <div>
                  <h3 className="text-2xl font-semibold mb-4 flex items-center">
                    <Globe className="mr-2 h-6 w-6 text-primary" /> Project Overview
                  </h3>
                  <ul className="space-y-3 list-disc pl-5 text-lg">
                    <li>
                      Empowers everyone to <strong>create, share, and enjoy living spaces</strong>, building a new
                      lifestyle economy
                    </li>
                    <li>
                      Participate with a <strong>low entry threshold</strong>, unlocking shared value and flexible
                      living
                    </li>
                    <li>Trade ownership shares and enjoy priority access to global living spaces</li>
                    <li>
                      Offers <strong>modular, adaptable, and eco-friendly living solutions</strong>
                    </li>
                    <li>
                      Future plans: expand into <strong>community-driven living networks worldwide</strong>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Key Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="overflow-hidden border-none shadow-lg">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-primary/20 p-4 rounded-full mb-4">
                  <CheckCircle2 className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-4">Low Entry Barrier</h3>
                <ul className="text-left space-y-2 list-disc pl-5">
                  <li>
                    Start participating with as little as <strong>$100</strong>
                  </li>
                  <li>Co-own curated living spaces with shared benefits</li>
                  <li>Simple, fast, and secure sign-up process</li>
                  <li>Transparent records ensuring clear participation rights</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none shadow-lg">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-primary/20 p-4 rounded-full mb-4">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-4">Community Ownership</h3>
                <ul className="text-left space-y-2 list-disc pl-5">
                  <li>
                    Join a <strong>global community</strong> of creators and explorers
                  </li>
                  <li>Collaborate in shaping shared spaces and experiences</li>
                  <li>Enjoy shared benefits from flexible living opportunities</li>
                  <li>Connect with like-minded communities worldwide</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none shadow-lg">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-primary/20 p-4 rounded-full mb-4">
                  <Lightbulb className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-4">Innovative Living</h3>
                <ul className="text-left space-y-2 list-disc pl-5">
                  <li>
                    <strong>Flexible, adaptive living spaces</strong> for modern lifestyles
                  </li>
                  <li>Designed for creativity, mobility, and community</li>
                  <li>Sustainable, eco-conscious designs</li>
                  <li>Empowering remote workers, travelers, and lifestyle seekers</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Market Challenges */}
          <Card className="overflow-hidden border-none shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 p-6">
              <div className="flex items-center gap-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-3xl font-bold">Solving Market Challenges</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-bold mb-4">Current Market Problems</h3>
                  <ul className="space-y-3 list-disc pl-5">
                    <li>
                      <strong>High entry barriers</strong> limit access to flexible living options
                    </li>
                    <li>
                      <strong>Complex legal processes</strong> hinder participation
                    </li>
                    <li>
                      <strong>Limited mobility</strong> in traditional living spaces
                    </li>
                    <li>
                      Lack of <strong>transparency</strong> in short-term stays
                    </li>
                    <li>
                      Renters miss out on <strong>meaningful participation benefits</strong>
                    </li>
                    <li>
                      <strong>Global uncertainties</strong> increase demand for secure, adaptable spaces
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-4">Our Solution</h3>
                  <ul className="space-y-3 list-disc pl-5">
                    <li>
                      <strong>Tokenizing spaces</strong> to expand access and participation
                    </li>
                    <li>
                      Creating a <strong>transparent marketplace</strong> for shared living solutions
                    </li>
                    <li>
                      Enabling participants to <strong>freely exchange living rights</strong>
                    </li>
                    <li>
                      <strong>Smart contracts</strong> ensure fair value distribution
                    </li>
                    <li>
                      No intermediaries, ensuring <strong>maximum community-driven efficiency</strong>
                    </li>
                    <li>
                      Empowering individuals to <strong>create, share, and thrive</strong> in new living spaces
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-none shadow-lg">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-4">DeProp & Nomapia: Shaping the Future of Living</h3>
              <p className="text-lg mb-6">
                DeProp is more than just a platform — it's a gateway to a new way of living. By combining modular
                architecture, shared ownership models, and a global community network, DeProp empowers you to build,
                earn, and thrive.
              </p>
              <p className="text-lg mb-6">
                With its streamlined design and powerful features, Nomapia empowers people to embrace a new vision of
                living — one that is flexible, secure, and future-ready.
              </p>
            </CardContent>
          </Card>

          <div className="text-center">
            <Button asChild size="lg" className="px-8 py-6 text-lg h-auto">
              <a href="/pitch-deck">
                View Full Pitch Deck <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

