import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import {
  Building,
  Globe,
  Code,
  Users,
  CheckCircle2,
  Lightbulb,
  Rocket,
  Home,
  Users2,
  MapPin,
  Globe2,
  Network,
  Shield,
  DollarSign,
  Wallet,
  Server,
  Plus,
  Minus,
  Landmark,
  Calendar,
  BarChart3,
  LineChart,
  PieChart,
} from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function PitchDeckPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-80 w-full">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202024-12-26%2017.21.52%20-%20A%20zoomed-in%20interior%20view%20of%20a%20modular%2C%20adaptive%20living%20space%20in%20a%20futuristic%20coastal%20community%20inspired%20by%20Tomorrowland%20and%20Avatar.%20The%20space%20showcas-coPhL9BgPbJx05RydTjnlps3LAzyIy.jpeg"
          alt="DeProp Vision"
          fill
          className="object-cover brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-transparent opacity-60" />
        <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">DeProp Pitch Deck</h1>
          <p className="text-xl text-white max-w-2xl mb-6">
            Revolutionizing real estate through decentralized ownership and booking
          </p>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-5xl mx-auto">
          <Accordion type="single" collapsible className="space-y-6">
            {/* Overview Section */}
            <AccordionItem value="overview" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-primary/20 p-3 rounded-full relative">
                        <Building className="h-8 w-8 text-primary" />
                        <div className="absolute -top-2 -left-2 bg-primary text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          01
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">DeProp: Empowering New Ways of Living</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <p className="text-lg mb-6">
                      DeProp empowers individuals to create, share, and experience flexible living spaces, building a
                      new vision of community living. With a low entry threshold, users can contribute, earn
                      proportional returns, and access inspiring living environments worldwide.
                    </p>
                    <p className="text-lg mb-6">
                      Currently, DeProp offers modular, adaptable housing solutions, with plans to expand into
                      community-driven living networks. By combining flexibility, ownership, and shared experiences,
                      DeProp ensures freedom of residence and fosters a secure, connected environment for well-being and
                      personal growth.
                    </p>

                    <h3 className="text-2xl font-semibold mb-4 flex items-center">
                      <Globe className="mr-2 h-6 w-6 text-primary" /> Project Overview
                    </h3>
                    <ul className="space-y-3 list-disc pl-5 mb-6">
                      <li>A decentralized platform that enables shared living spaces with flexible participation</li>
                      <li>Low entry threshold for easy access, fair returns, and exchangeable living rights</li>
                      <li>Offers modular housing solutions with plans for worldwide expansion</li>
                      <li>Focuses on freedom of movement, social well-being, and adaptable lifestyles</li>
                    </ul>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6">
                      <div className="bg-secondary/30 p-6 rounded-lg flex flex-col items-center text-center">
                        <div className="bg-primary/20 p-3 rounded-full mb-4">
                          <CheckCircle2 className="h-6 w-6 text-primary" />
                        </div>
                        <h4 className="font-semibold mb-2">Low Entry Barrier</h4>
                        <p>Start participating with as little as $100</p>
                        <p className="text-sm mt-1">Co-own thoughtfully designed living spaces</p>
                        <p className="text-sm mt-1">Easy onboarding with clear participation records</p>
                      </div>

                      <div className="bg-secondary/30 p-6 rounded-lg flex flex-col items-center text-center">
                        <div className="bg-primary/20 p-3 rounded-full mb-4">
                          <Users className="h-6 w-6 text-primary" />
                        </div>
                        <h4 className="font-semibold mb-2">Community Ownership</h4>
                        <p>Join a global network of creators and explorers</p>
                        <p className="text-sm mt-1">Shape your living space through collaboration</p>
                        <p className="text-sm mt-1">Enjoy shared benefits and community-driven value</p>
                      </div>

                      <div className="bg-secondary/30 p-6 rounded-lg flex flex-col items-center text-center">
                        <div className="bg-primary/20 p-3 rounded-full mb-4">
                          <Lightbulb className="h-6 w-6 text-primary" />
                        </div>
                        <h4 className="font-semibold mb-2">Innovative Living</h4>
                        <p>Flexible, modular housing solutions designed for modern lifestyles</p>
                        <p className="text-sm mt-1">Sustainable, mobile, and adaptable for changing needs</p>
                        <p className="text-sm mt-1">Ideal for remote workers, travelers, and community builders</p>
                      </div>
                    </div>
                    <div className="mt-6 bg-primary/5 p-6 rounded-lg">
                      <h3 className="text-xl font-semibold mb-3">
                        🌱 DeProp & Nomapia: Building a Future of Flexible Living
                      </h3>
                      <p className="text-base">
                        DeProp is more than just a platform — it's a bridge to a lifestyle upgrade. By blending modular
                        design, shared ownership, and vibrant communities, DeProp empowers people to build, earn, and
                        thrive in a new era of living.
                      </p>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Vision Section */}
            <AccordionItem value="vision" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-violet-500/10 to-violet-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-violet-500/20 p-3 rounded-full relative">
                        <Lightbulb className="h-8 w-8 text-violet-600" />
                        <div className="absolute -top-2 -left-2 bg-violet-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          02
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Vision</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <p className="text-lg mb-6">
                      Nomapia envisions a world where people can proactively choose a "Life Upgrade" — a flexible,
                      secure, and sustainable way of living that offers more than just a crisis fallback. As climate
                      change, geopolitical shifts, and digital lifestyles reshape our world, Nomapia provides a new
                      model for those seeking adaptable, resilient living spaces.
                    </p>

                    <div className="flex flex-col md:flex-row gap-8">
                      <div className="flex-1">
                        <h3 className="text-2xl font-semibold mb-4">Our Vision</h3>
                        <ul className="space-y-3 list-disc pl-5 mb-6">
                          <li>
                            A decentralized living network designed for forward-thinking communities and digital nomads.
                          </li>
                          <li>
                            Scalable, self-sufficient communities blending modular design with ecological solutions.
                          </li>
                          <li>Spaces designed for physical well-being, mental health, and social connection.</li>
                          <li>Emphasis on freedom of movement, security, and community co-creation.</li>
                          <li>Encourages skill exploration, creative work, and global collaboration.</li>
                        </ul>

                        <h3 className="text-2xl font-semibold mb-4 mt-6">Key Drivers of Well-Being</h3>
                        <ul className="space-y-2 list-disc pl-5">
                          <li>
                            Generosity & Community Engagement: Encouraging acts of kindness and inclusive participation.
                          </li>
                          <li>
                            Health & Sustainable Environments: Promoting ecological balance and personal well-being.
                          </li>
                          <li>Social Support & Trust: Building strong, reliable networks.</li>
                          <li>Freedom & Self-Determination: Empowering individual choices and autonomy.</li>
                        </ul>
                      </div>
                      <div className="flex-1 flex items-center justify-center">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%7BD79CDEF3-4BCA-435C-B238-C9DF338A9CB3%7D-FwpHLzq4QAagFoELz857nanpLqEfrp.png"
                          alt="Key Drivers of Well-Being"
                          width={500}
                          height={500}
                          className="object-contain"
                        />
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Market Challenges Section */}
            <AccordionItem value="market-challenges" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-amber-500/20 p-3 rounded-full relative">
                        <Shield className="h-8 w-8 text-amber-600" />
                        <div className="absolute -top-2 -left-2 bg-amber-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          03
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Solving Modern Living Challenges</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-semibold mb-6">Living Challenges vs. Solutions</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Challenge 1 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Users className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">🔒 Limited Accessibility</h4>
                        </div>
                        <p className="text-sm mb-2">
                          <strong>Challenge:</strong> High barriers to accessing alternative living spaces
                        </p>
                        <p className="text-sm">
                          <strong>Solution:</strong> Flexible entry with fractional ownership starting at $100
                        </p>
                      </div>

                      {/* Challenge 2 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Globe className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">🌍 Geographic Restrictions</h4>
                        </div>
                        <p className="text-sm mb-2">
                          <strong>Challenge:</strong> Relocating or establishing a second living base is complicated
                        </p>
                        <p className="text-sm">
                          <strong>Solution:</strong> Borderless platform enabling seamless entry with crypto payments
                        </p>
                      </div>

                      {/* Challenge 3 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <DollarSign className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">📊 Non-transparent Information</h4>
                        </div>
                        <p className="text-sm mb-2">
                          <strong>Challenge:</strong> Difficult to track housing options, community updates, and shared
                          resources
                        </p>
                        <p className="text-sm">
                          <strong>Solution:</strong> On-chain data visualization and automated distributions ensure
                          transparency
                        </p>
                      </div>

                      {/* Challenge 4 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Shield className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">⏳ Inflexible Entry/Exit</h4>
                        </div>
                        <p className="text-sm mb-2">
                          <strong>Challenge:</strong> Lengthy processes for joining or leaving a community
                        </p>
                        <p className="text-sm">
                          <strong>Solution:</strong> Flexible participation with smart contracts for instant entry/exit
                        </p>
                      </div>

                      {/* Challenge 5 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Wallet className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">💰 High Costs & Fees</h4>
                        </div>
                        <p className="text-sm mb-2">
                          <strong>Challenge:</strong> Expensive intermediary fees limit affordability
                        </p>
                        <p className="text-sm">
                          <strong>Solution:</strong> Automated processes with minimal platform fees
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Market Opportunity Now */}
            <AccordionItem value="market-opportunity" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-indigo-500/10 to-indigo-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-indigo-500/20 p-3 rounded-full relative">
                        <LineChart className="h-8 w-8 text-indigo-600" />
                        <div className="absolute -top-2 -left-2 bg-indigo-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          04
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Why Now?</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-indigo-500/20 p-2 rounded-full mr-3">
                            <Building className="h-5 w-5 text-indigo-600" />
                          </div>
                          <h4 className="text-lg font-bold">1. Climate Disruption</h4>
                        </div>
                        <p className="text-sm">
                          Extreme weather events, rising sea levels, and water scarcity are pushing people to seek
                          safer, more ecologically resilient places to live.
                        </p>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-indigo-500/20 p-2 rounded-full mr-3">
                            <Shield className="h-5 w-5 text-indigo-600" />
                          </div>
                          <h4 className="text-lg font-bold">2. Political and Social Instability</h4>
                        </div>
                        <p className="text-sm">
                          Growing threats of conflict, tightening national policies, or democratic backsliding are
                          prompting people to explore alternative places of settlement.
                        </p>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-indigo-500/20 p-2 rounded-full mr-3">
                            <Globe className="h-5 w-5 text-indigo-600" />
                          </div>
                          <h4 className="text-lg font-bold">3. Shifting Boundaries of Digital Life</h4>
                        </div>
                        <p className="text-sm">
                          Remote work and digital nomadism are redefining the need for a fixed primary base, making
                          mobility a viable lifestyle choice.
                        </p>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-indigo-500/20 p-2 rounded-full mr-3">
                            <Network className="h-5 w-5 text-indigo-600" />
                          </div>
                          <h4 className="text-lg font-bold">4. Increasing Desire for Systemic Resilience</h4>
                        </div>
                        <p className="text-sm">
                          The core anxiety of our time has shifted from "Where am I from?" to "Where can I survive—and
                          thrive?"
                        </p>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg md:col-span-2">
                        <div className="flex items-center mb-3">
                          <div className="bg-indigo-500/20 p-2 rounded-full mr-3">
                            <Lightbulb className="h-5 w-5 text-indigo-600" />
                          </div>
                          <h4 className="text-lg font-bold">5. Revaluation of Quality of Life</h4>
                        </div>
                        <p className="text-sm">
                          Second choices are often driven by values such as proximity to nature, community co-creation,
                          ecological living, and spiritual belonging.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Why is Nomapia/DeProp better than others */}
            <AccordionItem value="why-better" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-emerald-500/10 to-emerald-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-emerald-500/20 p-3 rounded-full relative">
                        <PieChart className="h-8 w-8 text-emerald-600" />
                        <div className="absolute -top-2 -left-2 bg-emerald-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          05
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Why is Nomapia/DeProp better than others</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-semibold mb-4">Redefining Decentralized Living in Web3</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <h4 className="text-lg font-bold mb-3 flex items-center">
                          <Users2 className="h-5 w-5 text-emerald-600 mr-2" />
                          vs. Web3 Hack Houses
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>True Ownership</strong> vs. temporary subsidized stays
                          </li>
                          <li>
                            <strong>Sustainable Revenue Model</strong> vs. sponsor dependence
                          </li>
                          <li>
                            <strong>DAO Governance</strong> vs. centralized decision-making
                          </li>
                          <li>
                            <strong>Real-World Utility</strong> vs. short-term events
                          </li>
                        </ul>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <h4 className="text-lg font-bold mb-3 flex items-center">
                          <Building className="h-5 w-5 text-emerald-600 mr-2" />
                          vs. Traditional Real Estate
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>NFT-based ownership</strong> vs. indirect shares
                          </li>
                          <li>
                            <strong>Low-entry investments</strong> vs. high barriers
                          </li>
                          <li>
                            <strong>Dual benefits</strong>: income + discounted stays
                          </li>
                          <li>
                            <strong>Transparent blockchain</strong> vs. opaque structures
                          </li>
                          <li>
                            <strong>Community control</strong> vs. institutional management
                          </li>
                        </ul>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <h4 className="text-lg font-bold mb-3 flex items-center">
                          <Globe2 className="h-5 w-5 text-emerald-600 mr-2" />
                          vs. Praxis / Forma City
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>Bottom-up approach</strong> vs. top-down city building
                          </li>
                          <li>
                            <strong>Start small, grow organically</strong> vs. mega-projects
                          </li>
                          <li>
                            <strong>Individual empowerment</strong> vs. institutional control
                          </li>
                          <li>
                            <strong>Decentralized expansion</strong> vs. centralized planning
                          </li>
                        </ul>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <h4 className="text-lg font-bold mb-3 flex items-center">
                          <Lightbulb className="h-5 w-5 text-emerald-600 mr-2" />
                          Why Choose DeProp / Nomapia?
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>True Ownership</strong> in real-world properties
                          </li>
                          <li>
                            <strong>Sustainable Business Model</strong> with real revenue
                          </li>
                          <li>
                            <strong>Bottom-Up Community Building</strong> starting small
                          </li>
                          <li>
                            <strong>Practical Web3 Implementation</strong> with tangible utility
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Technical Architecture */}
            <AccordionItem value="technical-architecture" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-blue-500/10 to-blue-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-blue-500/20 p-3 rounded-full relative">
                        <Code className="h-8 w-8 text-blue-600" />
                        <div className="absolute -top-2 -left-2 bg-blue-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          06
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Technical Architecture</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="bg-blue-50/50 p-4 rounded-lg border border-blue-100">
                        <h4 className="text-lg font-semibold mb-3 flex items-center">
                          <Code className="h-5 w-5 text-blue-600 mr-2" />
                          Frontend Architecture
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>Next.js 13+ App Router</strong> for optimal performance
                          </li>
                          <li>
                            <strong>React 18 Server Components</strong> for efficient rendering
                          </li>
                          <li>
                            <strong>shadcn/ui Component Library</strong> with custom extensions
                          </li>
                          <li>
                            <strong>Tailwind CSS</strong> responsive design system
                          </li>
                          <li>
                            <strong>ethers.js v6</strong> Web3 integration layer
                          </li>
                        </ul>
                      </div>

                      <div className="bg-secondary/20 p-4 rounded-lg">
                        <h4 className="text-lg font-semibold mb-3 flex items-center">
                          <Server className="h-5 w-5 text-blue-600 mr-2" />
                          Backend Architecture
                        </h4>
                        <ul className="list-disc pl-5 text-sm space-y-2">
                          <li>
                            <strong>Smart Contracts</strong> on Scroll Sepolia testnet
                          </li>
                          <li>
                            <strong>Next.js API Routes</strong> for server-side operations
                          </li>
                          <li>
                            <strong>Hybrid Data Model</strong> combining on-chain and off-chain data
                          </li>
                          <li>
                            <strong>Real-time UI updates</strong> via blockchain events
                          </li>
                          <li>
                            <strong>Automated distribution</strong> of returns and notifications
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="bg-blue-50/20 p-4 rounded-lg">
                      <h4 className="text-lg font-semibold mb-2">Key Technical Features</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Wallet Connection</p>
                          <p className="text-xs text-muted-foreground">MetaMask integration with network detection</p>
                        </div>
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Transaction Management</p>
                          <p className="text-xs text-muted-foreground">Gas estimation and confirmation tracking</p>
                        </div>
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Contract Interaction</p>
                          <p className="text-xs text-muted-foreground">Type-safe methods with error handling</p>
                        </div>
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Event Listeners</p>
                          <p className="text-xs text-muted-foreground">Real-time UI updates from blockchain</p>
                        </div>
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Ownership Tracking</p>
                          <p className="text-xs text-muted-foreground">Transparent on-chain property rights</p>
                        </div>
                        <div className="bg-white p-3 rounded border border-blue-100">
                          <p className="font-medium text-sm">Automated Returns</p>
                          <p className="text-xs text-muted-foreground">Smart contract-based distribution</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Future Roadmap */}
            <AccordionItem value="roadmap" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-purple-500/10 to-purple-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-purple-500/20 p-3 rounded-full relative">
                        <Rocket className="h-8 w-8 text-purple-600" />
                        <div className="absolute -top-2 -left-2 bg-purple-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          07
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">
                        Nomapia Roadmap: Building a Real Decentralized Living Network
                      </h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <div className="relative border-l-2 border-primary/30 pl-8 pb-4 space-y-6">
                      <div className="relative">
                        <div className="absolute -left-10 top-0 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center">
                          1
                        </div>
                        <div className="flex items-center mb-2">
                          <Home className="h-6 w-6 text-primary mr-3" />
                          <h4 className="text-xl font-semibold">Minimal Viable Unit (MVU)</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Start with one small house - real property, not virtual land</li>
                          <li>Ownership, revenue, and management data recorded on-chain</li>
                          <li>Low barrier to entry for independent lifestyle</li>
                        </ul>
                      </div>

                      <div className="relative">
                        <div className="absolute -left-10 top-0 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center">
                          2
                        </div>
                        <div className="flex items-center mb-2">
                          <Code className="h-6 w-6 text-primary mr-3" />
                          <h4 className="text-xl font-semibold">MVP: Real Decentralized Living</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Smart contracts managing ownership, revenue, check-in, leasing</li>
                          <li>Flexible entry/exit with transparent on-chain transactions</li>
                          <li>Real-world property with tangible value and returns</li>
                        </ul>
                      </div>

                      <div className="relative">
                        <div className="absolute -left-10 top-0 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center">
                          3
                        </div>
                        <div className="flex items-center mb-2">
                          <Users2 className="h-6 w-6 text-primary mr-3" />
                          <h4 className="text-xl font-semibold">Community Stage</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Modular houses forming natural communities</li>
                          <li>DAO voting for shared resource management</li>
                          <li>Flexible lifestyle for digital nomads and remote workers</li>
                        </ul>
                      </div>

                      <div className="relative">
                        <div className="absolute -left-10 top-0 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center">
                          4
                        </div>
                        <div className="flex items-center mb-2">
                          <MapPin className="h-6 w-6 text-primary mr-3" />
                          <h4 className="text-xl font-semibold">Offline Experience</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>"Sample communities" in various regions</li>
                          <li>Testing grounds and templates for expansion</li>
                          <li>Replicable model with DAO governance</li>
                        </ul>
                      </div>

                      <div className="relative">
                        <div className="absolute -left-10 top-0 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center">
                          5
                        </div>
                        <div className="flex items-center mb-2">
                          <Globe2 className="h-6 w-6 text-primary mr-3" />
                          <h4 className="text-xl font-semibold">Network State: A Global Living Network</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Connecting small, independent communities worldwide</li>
                          <li>Autonomous operations with shared values</li>
                          <li>Truly global decentralized living network</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Nomapia's Core Values */}
            <AccordionItem value="core-values" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-green-500/10 to-green-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-green-500/20 p-3 rounded-full relative">
                        <Globe className="h-8 w-8 text-green-600" />
                        <div className="absolute -top-2 -left-2 bg-green-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          08
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">
                        Nomapia's Core Values: Freedom, Flexibility, and Decentralization
                      </h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <p className="mb-4 text-lg">
                      Nomapia is not just about property — it's about creating a new kind of living experience:
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Building className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Freedom of Choice</h4>
                          <p className="text-sm">Independent, community-driven growth without centralized control</p>
                        </div>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Home className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Flexible Living</h4>
                          <p className="text-sm">Modular, sustainable design adapting to different environments</p>
                        </div>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Users className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Decentralized Governance</h4>
                          <p className="text-sm">Blockchain integration with transparent, democratic decision-making</p>
                        </div>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Globe className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Global Opportunity</h4>
                          <p className="text-sm">Secure, creative alternative for those seeking new living options</p>
                        </div>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Network className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Real-World Network State</h4>
                          <p className="text-sm">
                            Small, interconnected communities instead of massive centralized cities
                          </p>
                        </div>
                      </div>

                      <div className="bg-secondary/10 p-4 rounded-lg flex gap-3">
                        <div className="bg-primary/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mt-1">
                          <Code className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-1">Empowering Web3 Values</h4>
                          <p className="text-sm">Bridging blockchain with tangible, real-life benefits</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Development Path */}
            <AccordionItem value="development-path" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-amber-500/20 p-3 rounded-full relative">
                        <Calendar className="h-8 w-8 text-amber-600" />
                        <div className="absolute -top-2 -left-2 bg-amber-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          09
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Development Path</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-semibold mb-4">Phased Growth Strategy</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                      {/* Phase 1 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <BarChart3 className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">Phase 1: Minimal DAO & Content</h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">3-6 months</p>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>
                            <strong>Focus:</strong> Launch DAO, develop media content
                          </li>
                          <li>
                            <strong>Benefits:</strong> Community culture, DAO voting
                          </li>
                          <li>
                            <strong>Funding:</strong> Small-scale crowdfunding
                          </li>
                        </ul>
                      </div>

                      {/* Phase 2 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Building className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">Phase 2: BnB & Shared Offices</h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">6-12 months</p>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>
                            <strong>Focus:</strong> Build physical spaces, expand content
                          </li>
                          <li>
                            <strong>Benefits:</strong> Rental income, real data insights
                          </li>
                          <li>
                            <strong>Funding:</strong> Community fund or private funding
                          </li>
                        </ul>
                      </div>

                      {/* Phase 3 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Home className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">Phase 3: Nomapia Hotel</h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">12-18 months</p>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>
                            <strong>Focus:</strong> Launch hotel with amenities
                          </li>
                          <li>
                            <strong>Benefits:</strong> Steady income, mature governance
                          </li>
                          <li>
                            <strong>Funding:</strong> Series A / community crowdfunding
                          </li>
                        </ul>
                      </div>

                      {/* Phase 4 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Landmark className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">Phase 4: Villas & Multi-Industry</h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">18-30 months</p>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>
                            <strong>Focus:</strong> Eco-tourism villas, industry integration
                          </li>
                          <li>
                            <strong>Benefits:</strong> Diversified revenue, resilience
                          </li>
                          <li>
                            <strong>Funding:</strong> Series B / strategic capital
                          </li>
                        </ul>
                      </div>

                      {/* Phase 5 */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <div className="bg-amber-500/20 p-2 rounded-full mr-3">
                            <Globe className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="text-lg font-bold">Phase 5: Global Network</h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">30+ months</p>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>
                            <strong>Focus:</strong> Decentralized community network
                          </li>
                          <li>
                            <strong>Benefits:</strong> Global distribution, resource sharing
                          </li>
                          <li>
                            <strong>Funding:</strong> Self-sustaining ecosystem
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="bg-amber-50/30 p-4 rounded-lg">
                      <h3 className="text-lg font-semibold mb-2">Overall Strategy</h3>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        <li>Step-by-step development from small to large scale</li>
                        <li>Focus on DAO governance and tokenization</li>
                        <li>Integration of AI and ecological solutions</li>
                        <li>Content-driven community building</li>
                      </ul>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>

            {/* Our Team */}
            <AccordionItem value="our-team" className="border-none">
              <Card className="overflow-hidden border-none shadow-lg">
                <div className="bg-gradient-to-r from-pink-500/10 to-pink-600/5 p-6">
                  <AccordionTrigger className="flex items-center gap-4 w-full text-left py-0 hover:no-underline">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="bg-pink-500/20 p-3 rounded-full relative">
                        <Users2 className="h-8 w-8 text-pink-600" />
                        <div className="absolute -top-2 -left-2 bg-pink-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                          10
                        </div>
                      </div>
                      <h2 className="text-3xl font-bold">Our Team</h2>
                    </div>
                    <div className="flex-shrink-0 ml-2">
                      <Plus className="h-6 w-6 accordion-plus" />
                      <Minus className="h-6 w-6 accordion-minus" />
                    </div>
                  </AccordionTrigger>
                </div>
                <AccordionContent>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-semibold mb-4">Team Introduction</h3>

                    <p className="text-base mb-6">
                      Our diverse team blends architecture, design, engineering, and Web3 expertise to build the future
                      of decentralized living.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      {/* Gen */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="bg-pink-500/20 p-2 rounded-full mr-3">
                            <Building className="h-5 w-5 text-pink-600" />
                          </div>
                          <h4 className="text-lg font-bold">Gen - Lead Urban Designer & Architect</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>10 years in urban design and architecture</li>
                          <li>Specializes in sustainable, community-driven spaces</li>
                        </ul>
                      </div>

                      {/* Rikito Ryu */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="bg-pink-500/20 p-2 rounded-full mr-3">
                            <Lightbulb className="h-5 w-5 text-pink-600" />
                          </div>
                          <h4 className="text-lg font-bold">Rikito Ryu - Creative Engineer</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Former Walt Disney Imagineer</li>
                          <li>APEC Lead at Scriptum AI</li>
                        </ul>
                      </div>

                      {/* Jeremiar */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="bg-pink-500/20 p-2 rounded-full mr-3">
                            <Code className="h-5 w-5 text-pink-600" />
                          </div>
                          <h4 className="text-lg font-bold">Jeremiar - Web3 & Tech Advisor</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Software engineering with Web3 focus</li>
                          <li>Building materials industry expertise</li>
                          <li>Technical development support</li>
                        </ul>
                      </div>

                      {/* Dennis */}
                      <div className="bg-secondary/10 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="bg-pink-500/20 p-2 rounded-full mr-3">
                            <Landmark className="h-5 w-5 text-pink-600" />
                          </div>
                          <h4 className="text-lg font-bold">Dennis - Senior Architect & Industrial Expert</h4>
                        </div>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          <li>Experienced architect with building systems knowledge</li>
                          <li>Factory owner specializing in building parts production</li>
                        </ul>
                      </div>
                    </div>

                    <div className="bg-pink-50/50 p-4 rounded-lg border border-pink-100">
                      <p className="text-base">
                        Our team combines creative innovation with practical execution expertise, making decentralized
                        living both achievable and impactful.
                      </p>
                    </div>
                  </CardContent>
                </AccordionContent>
              </Card>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </div>
  )
}

