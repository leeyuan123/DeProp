"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/context/web3-context"
import { useToast } from "@/components/ui/use-toast"
import { ArrowUpRight, ArrowDownRight, DollarSign } from "lucide-react"
import { ProtectedRoute } from "@/components/protected-route"

interface Investment {
  propertyId: string
  name: string
  investedAmount: number
  currentValue: number
  rentalIncome: number
}

export default function DashboardPage() {
  const router = useRouter()
  const { isConnected, address, contract } = useWeb3()
  const { toast } = useToast()
  const [investments, setInvestments] = useState<Investment[]>([])

  useEffect(() => {
    if (!isConnected) {
      router.push("/")
      return
    }

    const fetchInvestments = async () => {
      if (contract && address) {
        try {
          // This is a placeholder. In a real application, you would fetch this data from your smart contract.
          const mockInvestments: Investment[] = [
            {
              propertyId: "1",
              name: "Diamond Cabin",
              investedAmount: 0.5,
              currentValue: 0.55,
              rentalIncome: 0.02,
            },
            {
              propertyId: "2",
              name: "Glashaus",
              investedAmount: 0.3,
              currentValue: 0.32,
              rentalIncome: 0.015,
            },
          ]
          setInvestments(mockInvestments)
        } catch (error) {
          console.error("Error fetching investments:", error)
          toast({
            title: "Error",
            description: "Failed to fetch investment data. Please try again later.",
            variant: "destructive",
          })
        }
      }
    }

    fetchInvestments()
  }, [isConnected, address, contract, router, toast])

  const handleSell = (propertyId: string) => {
    // Placeholder for sell functionality
    toast({
      title: "Sell request received",
      description: `Your request to sell property ${propertyId} has been received. This feature is not yet implemented.`,
    })
  }

  if (!isConnected) {
    return null // This will prevent any flash of content before redirect
  }

  const totalInvested = investments.reduce((sum, inv) => sum + inv.investedAmount, 0)
  const totalCurrentValue = investments.reduce((sum, inv) => sum + inv.currentValue, 0)
  const totalRentalIncome = investments.reduce((sum, inv) => sum + inv.rentalIncome, 0)

  return (
    <ProtectedRoute>
      <div className="container py-10">
        <h1 className="text-4xl font-bold mb-8">Your Investment Dashboard</h1>

        <div className="grid gap-6 md:grid-cols-3 mb-12">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <DollarSign className="mr-2" /> Total Invested
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{totalInvested.toFixed(2)} USDT</p>
            </CardContent>
          </Card>
          <Card className="bg-secondary">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <ArrowUpRight className="mr-2" /> Current Value
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{totalCurrentValue.toFixed(2)} USDT</p>
            </CardContent>
          </Card>
          <Card className="bg-accent">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <ArrowDownRight className="mr-2" /> Total Rental Income
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{totalRentalIncome.toFixed(2)} USDT</p>
            </CardContent>
          </Card>
        </div>

        <h2 className="text-2xl font-semibold mb-6">Your Properties</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {investments.map((investment) => (
            <Card key={investment.propertyId} className="overflow-hidden">
              <CardHeader className="bg-secondary">
                <CardTitle>{investment.name}</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Invested Amount:</span>
                    <span className="font-semibold">{investment.investedAmount} USDT</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Current Value:</span>
                    <span className="font-semibold">{investment.currentValue} USDT</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Rental Income:</span>
                    <span className="font-semibold">{investment.rentalIncome} USDT</span>
                  </div>
                  <div className="flex justify-between pt-4 border-t">
                    <span className="font-semibold">Total Profit:</span>
                    <span className="font-bold text-green-600">
                      {(investment.currentValue - investment.investedAmount + investment.rentalIncome).toFixed(3)} USDT
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardContent className="bg-secondary p-6">
                <Button onClick={() => handleSell(investment.propertyId)} className="w-full" variant="default">
                  Sell Property
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </ProtectedRoute>
  )
}

