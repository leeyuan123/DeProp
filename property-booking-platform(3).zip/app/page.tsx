import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { products } from "@/data/products"
import { Navbar } from "@/components/navbar"
import { Wallet, Building, Calendar } from "lucide-react"

export default function Home() {
  // Only use Diamond Cabin for the main actions
  const diamondCabin = products.find((product) => product.id === "1")

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section className="relative flex items-center justify-center min-h-[80vh] text-white">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202024-12-26%2017.21.52%20-%20A%20zoomed-in%20interior%20view%20of%20a%20modular%2C%20adaptive%20living%20space%20in%20a%20futuristic%20coastal%20community%20inspired%20by%20Tomorrowland%20and%20Avatar.%20The%20space%20showcas-coPhL9BgPbJx05RydTjnlps3LAzyIy.jpeg"
          alt="Future of living"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
          <h1 className="text-5xl font-bold mb-6 leading-tight">The Future of Product Investment</h1>
          <p className="text-xl mb-12 text-gray-200">
            Experience luxury living and smart investing with our curated collection of premium products
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Button asChild className="bg-white hover:bg-white/90 text-black text-xl px-12 py-8 h-auto font-semibold">
              <Link href={`/invest/${diamondCabin?.id}`}>Start Investing</Link>
            </Button>
            <Button
              asChild
              className="bg-transparent hover:bg-white/10 text-white text-xl px-12 py-8 h-auto font-semibold border-2 border-white"
            >
              <Link href={`/book/${diamondCabin?.id}`}>Book a Stay</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Available Products Section */}
      <section className="container mx-auto px-4 py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl font-bold mb-4">Available Products</h2>
          <p className="text-xl text-muted-foreground">
            Discover our collection of premium products ready for investment
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {products.map((product) => (
            <div key={product.id}>
              {product.isComingSoon ? (
                <ProductCard product={product} comingSoon />
              ) : (
                <Link href={`/invest/${product.id}`}>
                  <ProductCard product={product} />
                </Link>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-secondary/10">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground">Three simple steps to start your investment journey</p>
          </div>
          <div className="grid md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="bg-primary/10 text-primary rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Wallet className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Connect Your Wallet</h3>
              <p className="text-muted-foreground">Link your crypto wallet to start investing or booking stays.</p>
            </div>
            <div className="text-center">
              <div className="bg-primary/10 text-primary rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Building className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Choose Your Action</h3>
              <p className="text-muted-foreground">Decide whether you want to invest in a product or book a stay.</p>
            </div>
            <div className="text-center">
              <div className="bg-primary/10 text-primary rounded-full p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Calendar className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Confirm and Enjoy</h3>
              <p className="text-muted-foreground">
                Complete your transaction and enjoy the benefits of decentralized product management.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

