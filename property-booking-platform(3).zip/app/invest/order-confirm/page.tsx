"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { properties } from "@/data/properties"
import { Progress } from "@/components/ui/progress"
import { ethers } from "ethers"
import { NetworkAlert } from "@/components/network-alert"

export default function OrderConfirmPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { isConnected, address, ethBalance, contract, isCorrectNetwork, switchNetwork } = useWeb3()
  const [isProcessing, setIsProcessing] = useState(false)

  const propertyId = searchParams.get("propertyId")
  const amount = searchParams.get("amount")
  const property = properties.find((p) => p.id === propertyId)

  useEffect(() => {
    if (!isConnected || !property || !amount) {
      router.push("/properties")
    }
  }, [isConnected, property, amount, router])

  const handleConfirmOrder = async () => {
    if (!isConnected || !address || !contract) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet first.",
        variant: "destructive",
      })
      return
    }

    if (!isCorrectNetwork) {
      toast({
        title: "Wrong Network",
        description: "Please switch to the correct network to perform this action.",
        variant: "destructive",
      })
      await switchNetwork()
      return
    }

    setIsProcessing(true)
    try {
      // Convert amount to Wei
      const amountInWei = ethers.parseEther(amount || "0")

      // Get project details
      const projectId = Number(property?.id)

      // Use a default seller address for the demo
      const sellerAddress = "0x0000000000000000000000000000000000000001"

      console.log("Placing order with:", {
        projectId,
        sellerAddress,
        amount: amountInWei.toString(),
        from: address,
      })

      // Call the contract's placeOrder function with value
      const tx = await contract.placeOrder(projectId, sellerAddress, {
        value: amountInWei,
        gasLimit: 500000,
      })

      toast({
        title: "Order Placed",
        description: "Transaction submitted. Please wait for confirmation.",
      })

      // Wait for transaction confirmation
      const receipt = await tx.wait()
      console.log("Transaction confirmed:", receipt)

      toast({
        title: "Success",
        description: `Successfully invested ${amount} ETH in ${property?.name}`,
      })

      // Redirect to order page
      router.push("/order")
    } catch (error: any) {
      console.error("Transaction failed:", error)

      let errorMessage = "Transaction failed. Please try again."
      if (error.message.includes("insufficient funds")) {
        errorMessage = "Insufficient funds to cover investment amount and gas fees."
      } else if (error.message.includes("user rejected")) {
        errorMessage = "Transaction was rejected. Please try again."
      } else if (error.message.includes("execution reverted")) {
        errorMessage = "Transaction reverted. Please check investment amount and try again."
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (!property || !amount) {
    return null
  }

  const fundingPercentage = (property.fundingCurrent / property.fundingGoal) * 100
  const expectedReturn = (Number(amount) * property.expectedRoi) / 100
  const ownershipPercentage = (Number(amount) / property.fundingGoal) * 100

  return (
    <div className="container max-w-2xl py-10">
      <NetworkAlert isCorrectNetwork={isCorrectNetwork} switchNetwork={switchNetwork} />

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Confirm Your Investment</CardTitle>
          <CardDescription>Please review your investment details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center space-x-4">
            <div className="relative h-24 w-24">
              <Image
                src={property.image || "/placeholder.svg"}
                alt={property.name}
                fill
                className="object-cover rounded-md"
              />
            </div>
            <div>
              <h3 className="text-lg font-semibold">{property.name}</h3>
              <p className="text-sm text-muted-foreground">{property.location}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Investment Amount</p>
              <p className="text-lg font-semibold">{amount} ETH</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Your Balance</p>
              <p className="text-lg font-semibold">{Number(ethBalance).toFixed(4)} ETH</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Expected Annual Return</p>
              <p className="text-lg font-semibold">
                {expectedReturn.toFixed(4)} ETH ({property.expectedRoi}%)
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Ownership Percentage</p>
              <p className="text-lg font-semibold">{ownershipPercentage.toFixed(2)}%</p>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Funding Progress</p>
            <Progress value={fundingPercentage} className="h-2" />
            <div className="flex justify-between text-sm mt-1">
              <span>{property.fundingCurrent.toLocaleString()} ETH raised</span>
              <span>{property.fundingGoal.toLocaleString()} ETH goal</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.back()} disabled={isProcessing}>
            Modify Order
          </Button>
          <Button onClick={handleConfirmOrder} disabled={isProcessing}>
            {isProcessing ? "Processing..." : "Confirm Investment"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

