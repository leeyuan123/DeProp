"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { WalletIcon, Plus, ArrowUpRight, ArrowDownLeft, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/context/auth-context"
import { useWallet } from "@/context/wallet-context"
import { useToast } from "@/components/ui/use-toast"
import { useWeb3 } from "@/context/web3-context"
import { ProtectedRoute } from "@/components/protected-route"

interface Transaction {
  id: string
  type: "deposit" | "withdrawal" | "investment" | "booking"
  amount: number
  date: Date
  description: string
}

export default function WalletPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { address, isConnected, isConnecting, connectWallet } = useWeb3()

  // Use state to track if component is mounted
  const [isMounted, setIsMounted] = useState(false)
  const [depositAmount, setDepositAmount] = useState(100)
  const [withdrawAmount, setWithdrawAmount] = useState(100)
  const [isProcessing, setIsProcessing] = useState(false)
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])

  // Only call hooks once
  const auth = useAuth()

  // Set isMounted to true when component mounts
  useEffect(() => {
    setIsMounted(true)

    // Mock transactions
    setTransactions([
      {
        id: "1",
        type: "deposit",
        amount: 1000,
        date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        description: "Initial deposit",
      },
      {
        id: "2",
        type: "investment",
        amount: -500,
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        description: "Investment in Luxury Beachfront Villa",
      },
      {
        id: "3",
        type: "booking",
        amount: -1500,
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        description: "Booking at Downtown Luxury Apartment",
      },
      {
        id: "4",
        type: "deposit",
        amount: 1000,
        date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        description: "Added funds",
      },
    ])

    // Set mock balance
    setBalance(1000)
  }, [])

  // Only access hooks if component is mounted
  const wallet = useWallet()

  const handleDeposit = () => {
    if (depositAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a positive amount.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate transaction delay
    setTimeout(() => {
      if (isMounted) {
        wallet.addFunds(depositAmount)
        setBalance((prev) => prev + depositAmount)
        setIsProcessing(false)

        // Add transaction to list
        setTransactions((prev) => [
          {
            id: Math.random().toString(),
            type: "deposit",
            amount: depositAmount,
            date: new Date(),
            description: "Added funds",
          },
          ...prev,
        ])
      }
    }, 1500)
  }

  const handleWithdraw = () => {
    if (withdrawAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a positive amount.",
        variant: "destructive",
      })
      return
    }

    if (withdrawAmount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You do not have enough USDT in your wallet.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate transaction delay
    setTimeout(() => {
      if (isMounted) {
        wallet.withdrawFunds(withdrawAmount)
        setBalance((prev) => prev - withdrawAmount)
        setIsProcessing(false)

        // Add transaction to list
        setTransactions((prev) => [
          {
            id: Math.random().toString(),
            type: "withdrawal",
            amount: -withdrawAmount,
            date: new Date(),
            description: "Withdrew funds",
          },
          ...prev,
        ])
      }
    }, 1500)
  }

  const handleConnect = async () => {
    try {
      await connectWallet()
    } catch (error) {
      console.error("Failed to connect wallet:", error)
      toast({
        title: "Error",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      })
    }
  }

  // If not mounted yet, return loading state
  if (!isMounted) {
    return <div className="container py-10">Loading wallet...</div>
  }

  // If no user and component is mounted, redirect
  if (isMounted && !auth.user) {
    router.push("/")
    return null
  }

  return (
    <ProtectedRoute>
      <div className="container py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Wallet</h1>
          <p className="text-muted-foreground mt-1">Manage your USDT balance</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <WalletIcon className="mr-2 h-5 w-5" />
                  Your Balance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold">{balance} USDT</div>
                <p className="text-sm text-muted-foreground mt-2">
                  Your simulated USDT balance for investing and booking
                </p>
              </CardContent>
            </Card>

            <Tabs defaultValue="deposit" className="space-y-4">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="deposit">Deposit</TabsTrigger>
                <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
              </TabsList>

              <TabsContent value="deposit">
                <Card>
                  <CardHeader>
                    <CardTitle>Add Funds</CardTitle>
                    <CardDescription>Add USDT to your wallet for investing and booking</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Amount (USDT)</label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            value={depositAmount}
                            onChange={(e) => setDepositAmount(Number(e.target.value))}
                            min={1}
                            disabled={isProcessing}
                          />
                          <span className="font-medium">USDT</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={handleDeposit} disabled={isProcessing || depositAmount <= 0} className="w-full">
                      {isProcessing ? (
                        <>
                          <Clock className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Plus className="mr-2 h-4 w-4" />
                          Add Funds
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="withdraw">
                <Card>
                  <CardHeader>
                    <CardTitle>Withdraw Funds</CardTitle>
                    <CardDescription>Withdraw USDT from your wallet</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Amount (USDT)</label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                            min={1}
                            max={balance}
                            disabled={isProcessing}
                          />
                          <span className="font-medium">USDT</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      onClick={handleWithdraw}
                      disabled={isProcessing || withdrawAmount <= 0 || withdrawAmount > balance}
                      className="w-full"
                    >
                      {isProcessing ? (
                        <>
                          <Clock className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <ArrowUpRight className="mr-2 h-4 w-4" />
                          Withdraw Funds
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
            <div className="space-y-4 mt-6">
              <Button onClick={handleConnect} disabled={isConnected || isConnecting}>
                {isConnected
                  ? `Connected: ${address?.slice(0, 6)}...${address?.slice(-4)}`
                  : isConnecting
                    ? "Connecting..."
                    : "Connect Wallet"}
              </Button>
              {isConnected && (
                <p className="text-green-600">Your wallet is connected. You can now invest or book properties.</p>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>Your recent wallet activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-4">
                        <div
                          className={`h-10 w-10 rounded-full flex items-center justify-center ${
                            transaction.amount > 0 ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                          }`}
                        >
                          {transaction.amount > 0 ? (
                            <ArrowDownLeft className="h-5 w-5" />
                          ) : (
                            <ArrowUpRight className="h-5 w-5" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{transaction.description}</p>
                          <p className="text-sm text-muted-foreground">
                            {transaction.date.toLocaleDateString()} at {transaction.date.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className={`font-semibold ${transaction.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                        {transaction.amount > 0 ? "+" : ""}
                        {transaction.amount} USDT
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}

